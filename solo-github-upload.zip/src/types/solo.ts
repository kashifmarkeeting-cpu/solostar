export type ThemeId =
  | 'royal-purple'
  | 'cyber-blue'
  | 'cinematic-red'
  | 'matrix-green';

export interface ThemeConfig {
  id: ThemeId;
  name: string;
  subtitle: string;
  motif: 'crown-smoke' | 'cyber-grid' | 'crimson-beams' | 'matrix-rain';
  bg: string;
  surface: string;
  surfaceElevated: string;
  accent: string;
  accentBright: string;
  accentMuted: string;
  border: string;
  borderSubtle: string;
  glow: string;
  text: string;
  textMuted: string;
  particleColors: string[];
  smokeColor: string;
  harmonicRootHz: number;
  swatchGradient: string;
}

export interface SoundPreferences {
  masterEnabled: boolean;
  ambientEnabled: boolean;
  sfxEnabled: boolean;
  ambientVolume: number;
  sfxVolume: number;
}

export interface ProjectItem {
  id: string;
  title: string;
  category: 'Interactive' | 'Design Systems' | 'Spatial & WebGL';
  year: string;
  summary: string;
  description: string;
  image: string;
  aspectRatio: '16:9' | '4:3';
  technologies: string[];
  architectureNotes: string[];
  deliverables: string[];
  conceptStatus: string;
}

export interface SkillGroup {
  id: string;
  label: string;
  headline: string;
  description: string;
  capabilities: {
    name: string;
    tier: 'Core Craft' | 'Specialized' | 'Exploratory';
    detail: string;
    tools: string[];
  }[];
}

export interface ServiceItem {
  index: string;
  title: string;
  description: string;
  deliverables: string[];
}

export interface ProcessStep {
  step: string;
  title: string;
  description: string;
  outcome: string;
}

export interface JourneyMilestone {
  phase: string;
  title: string;
  focus: string;
  description: string;
}

export type SfxKind =
  | 'click'
  | 'nav'
  | 'theme'
  | 'menuOpen'
  | 'menuClose'
  | 'success'
  | 'error';
