import React, { useEffect, useState } from 'react';
import { AboutSection } from './components/AboutSection';
import { AmbientCanvas } from './components/AmbientCanvas';
import { ContactSection } from './components/ContactSection';
import { CustomCursor } from './components/CustomCursor';
import { Footer } from './components/Footer';
import { HeroSection } from './components/HeroSection';
import { Navbar } from './components/Navbar';
import { NotFoundView } from './components/NotFoundView';
import { ProcessAndJourneySection } from './components/ProcessAndJourneySection';
import { ProjectsSection } from './components/ProjectsSection';
import { OfflineIndicator } from './components/PWAStatus';
import { ScrollProgress } from './components/ScrollProgress';
import { SkillsSection } from './components/SkillsSection';
import { SplashScreen } from './components/SplashScreen';
import { SoloProvider, useSolo } from './context/SoloContext';

const KNOWN_PATHS = new Set(['/', '/index.html', '']);

const SoloShell: React.FC = () => {
  const { setActiveSection } = useSolo();
  const [splashDone, setSplashDone] = useState(false);
  const [isNotFound, setIsNotFound] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return !KNOWN_PATHS.has(window.location.pathname);
  });

  // Scroll-spy observer for navigation highlight
  useEffect(() => {
    if (isNotFound) return;
    const sectionIds = ['home', 'about', 'projects', 'skills', 'contact'];
    const elements = sectionIds
      .map((id) => document.getElementById(id))
      .filter((el): el is HTMLElement => Boolean(el));

    if (elements.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio);
        if (visible[0]?.target?.id) {
          setActiveSection(visible[0].target.id);
        }
      },
      { rootMargin: '-25% 0px -45% 0px', threshold: [0.1, 0.35, 0.6] }
    );

    elements.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, [isNotFound, setActiveSection, splashDone]);

  const handleReturnHome = () => {
    window.history.pushState({}, '', '/');
    setIsNotFound(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="relative min-h-screen text-[var(--solo-text)]">
      {!splashDone && <SplashScreen onComplete={() => setSplashDone(true)} />}

      <AmbientCanvas />
      <CustomCursor />
      <OfflineIndicator />

      {isNotFound ? (
        <NotFoundView onReturnHome={handleReturnHome} />
      ) : (
        <>
          <ScrollProgress />
          <Navbar />

          <main className="relative z-10">
            <HeroSection />
            <AboutSection />
            <ProjectsSection />
            <SkillsSection />
            <ProcessAndJourneySection />
            <ContactSection />
          </main>

          <Footer
            onShowNotFound={() => {
              window.history.pushState({}, '', '/404');
              setIsNotFound(true);
              window.scrollTo({ top: 0 });
            }}
          />
        </>
      )}
    </div>
  );
};

export default function App() {
  return (
    <SoloProvider>
      <SoloShell />
    </SoloProvider>
  );
}
