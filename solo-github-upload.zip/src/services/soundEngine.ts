import type { SfxKind, SoundPreferences } from '../types/solo';

class SoloSoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private ambientGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private filterNode: BiquadFilterNode | null = null;
  private oscillators: OscillatorNode[] = [];
  private lfoOsc: OscillatorNode | null = null;
  private isAmbientRunning = false;
  private currentRootHz = 73.42;
  private lastSfxTime = new Map<SfxKind, number>();
  private prefs: SoundPreferences = {
    masterEnabled: false,
    ambientEnabled: true,
    sfxEnabled: true,
    ambientVolume: 0.35,
    sfxVolume: 0.45,
  };

  private ensureContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext })
          .webkitAudioContext;
      if (!AudioCtx) return null;
      this.ctx = new AudioCtx();

      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = this.prefs.masterEnabled ? 1 : 0;
      this.masterGain.connect(this.ctx.destination);

      this.ambientGain = this.ctx.createGain();
      this.ambientGain.gain.value = 0;
      this.ambientGain.connect(this.masterGain);

      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.value = this.prefs.sfxEnabled
        ? this.prefs.sfxVolume * 0.35
        : 0;
      this.sfxGain.connect(this.masterGain);
    }
    if (this.ctx.state === 'suspended') {
      void this.ctx.resume();
    }
    return this.ctx;
  }

  public syncPreferences(next: SoundPreferences, rootHz?: number): void {
    this.prefs = { ...next };
    if (rootHz) {
      this.currentRootHz = rootHz;
    }

    if (!this.ctx || !this.masterGain || !this.ambientGain || !this.sfxGain) {
      return;
    }

    const now = this.ctx.currentTime;
    this.masterGain.gain.cancelScheduledValues(now);
    this.masterGain.gain.setTargetAtTime(
      next.masterEnabled ? 1 : 0,
      now,
      0.08
    );

    const targetAmbient =
      next.masterEnabled && next.ambientEnabled ? next.ambientVolume * 0.18 : 0;
    this.ambientGain.gain.cancelScheduledValues(now);
    this.ambientGain.gain.setTargetAtTime(targetAmbient, now, 0.25);

    const targetSfx =
      next.masterEnabled && next.sfxEnabled ? next.sfxVolume * 0.32 : 0;
    this.sfxGain.gain.cancelScheduledValues(now);
    this.sfxGain.gain.setTargetAtTime(targetSfx, now, 0.05);

    if (next.masterEnabled && next.ambientEnabled) {
      this.startAmbientPad();
      this.updateAmbientRoot(this.currentRootHz);
    } else if (!next.masterEnabled || !next.ambientEnabled) {
      // Keep oscillators softly muted or stop cleanly when disabled
      if (!next.masterEnabled && this.isAmbientRunning) {
        this.stopAmbientPad();
      }
    }
  }

  public activateFromUserGesture(
    next: SoundPreferences,
    rootHz: number
  ): void {
    this.currentRootHz = rootHz;
    const ctx = this.ensureContext();
    if (!ctx) return;
    this.syncPreferences(next, rootHz);
  }

  private startAmbientPad(): void {
    if (this.isAmbientRunning || !this.ctx || !this.ambientGain) return;

    const now = this.ctx.currentTime;
    this.filterNode = this.ctx.createBiquadFilter();
    this.filterNode.type = 'lowpass';
    this.filterNode.frequency.setValueAtTime(420, now);
    this.filterNode.Q.setValueAtTime(1.2, now);
    this.filterNode.connect(this.ambientGain);

    // Gentle breathing LFO modulating filter cutoff
    this.lfoOsc = this.ctx.createOscillator();
    const lfoGain = this.ctx.createGain();
    this.lfoOsc.type = 'sine';
    this.lfoOsc.frequency.setValueAtTime(0.08, now);
    lfoGain.gain.setValueAtTime(140, now);
    this.lfoOsc.connect(lfoGain);
    lfoGain.connect(this.filterNode.frequency);
    this.lfoOsc.start(now);

    // Warm 3-voice harmonic drone (root, fifth, octave+ninth shimmer)
    const ratios = [1, 1.5, 2.25];
    const types: OscillatorType[] = ['sine', 'triangle', 'sine'];

    this.oscillators = ratios.map((ratio, idx) => {
      const osc = this.ctx!.createOscillator();
      const voiceGain = this.ctx!.createGain();
      osc.type = types[idx];
      osc.frequency.setValueAtTime(this.currentRootHz * ratio, now);
      osc.detune.setValueAtTime((idx - 1) * 4, now);
      voiceGain.gain.setValueAtTime(idx === 0 ? 0.5 : idx === 1 ? 0.26 : 0.12, now);
      osc.connect(voiceGain);
      voiceGain.connect(this.filterNode!);
      osc.start(now);
      return osc;
    });

    this.isAmbientRunning = true;
  }

  private stopAmbientPad(): void {
    if (!this.isAmbientRunning) return;
    try {
      this.oscillators.forEach((osc) => {
        osc.stop();
        osc.disconnect();
      });
      this.lfoOsc?.stop();
      this.lfoOsc?.disconnect();
      this.filterNode?.disconnect();
    } catch {
      // Ignore already stopped oscillators
    }
    this.oscillators = [];
    this.lfoOsc = null;
    this.filterNode = null;
    this.isAmbientRunning = false;
  }

  public updateAmbientRoot(rootHz: number): void {
    this.currentRootHz = rootHz;
    if (!this.ctx || !this.isAmbientRunning) return;
    const now = this.ctx.currentTime;
    const ratios = [1, 1.5, 2.25];
    this.oscillators.forEach((osc, idx) => {
      osc.frequency.setTargetAtTime(rootHz * ratios[idx], now, 0.45);
    });
  }

  public playSfx(kind: SfxKind): void {
    if (!this.prefs.masterEnabled || !this.prefs.sfxEnabled) return;
    const nowMs = performance.now();
    const prevMs = this.lastSfxTime.get(kind) ?? 0;
    // Prevent overlapping / rapid spam
    if (nowMs - prevMs < 95) return;
    this.lastSfxTime.set(kind, nowMs);

    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;

    const now = ctx.currentTime;

    const triggerTone = (
      freqStart: number,
      freqEnd: number,
      duration: number,
      type: OscillatorType = 'sine',
      delay = 0,
      peak = 0.25
    ) => {
      const osc = ctx.createOscillator();
      const env = ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freqStart, now + delay);
      osc.frequency.exponentialRampToValueAtTime(
        Math.max(40, freqEnd),
        now + delay + duration
      );

      env.gain.setValueAtTime(0.0001, now + delay);
      env.gain.linearRampToValueAtTime(peak, now + delay + 0.015);
      env.gain.exponentialRampToValueAtTime(0.0001, now + delay + duration);

      osc.connect(env);
      env.connect(this.sfxGain!);
      osc.start(now + delay);
      osc.stop(now + delay + duration + 0.02);
    };

    switch (kind) {
      case 'click':
        triggerTone(520, 340, 0.075, 'sine', 0, 0.2);
        break;
      case 'nav':
        triggerTone(440, 587.33, 0.11, 'triangle', 0, 0.16);
        break;
      case 'theme':
        triggerTone(293.66, 440, 0.22, 'sine', 0, 0.18);
        triggerTone(587.33, 659.25, 0.26, 'sine', 0.06, 0.12);
        break;
      case 'menuOpen':
        triggerTone(392, 523.25, 0.14, 'sine', 0, 0.16);
        break;
      case 'menuClose':
        triggerTone(523.25, 392, 0.12, 'sine', 0, 0.14);
        break;
      case 'success':
        triggerTone(440, 440, 0.16, 'sine', 0, 0.18);
        triggerTone(554.37, 554.37, 0.18, 'sine', 0.08, 0.18);
        triggerTone(659.25, 659.25, 0.28, 'sine', 0.16, 0.2);
        break;
      case 'error':
        triggerTone(240, 180, 0.16, 'triangle', 0, 0.2);
        break;
    }
  }
}

export const soundEngine = new SoloSoundEngine();
