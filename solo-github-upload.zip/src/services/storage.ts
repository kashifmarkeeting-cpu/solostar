// Platform-agnostic storage layer ready for Capacitor Preferences migration.
const memoryFallback = new Map<string, string>();

export const storage = {
  get<T>(key: string, fallback: T): T {
    try {
      const raw =
        typeof window !== 'undefined'
          ? window.localStorage.getItem(key)
          : memoryFallback.get(key) ?? null;
      if (!raw) return fallback;
      return JSON.parse(raw) as T;
    } catch {
      return fallback;
    }
  },

  set<T>(key: string, value: T): void {
    try {
      const serialized = JSON.stringify(value);
      if (typeof window !== 'undefined') {
        window.localStorage.setItem(key, serialized);
      } else {
        memoryFallback.set(key, serialized);
      }
    } catch {
      // Ignore storage quota or private-mode errors gracefully
    }
  },
};
