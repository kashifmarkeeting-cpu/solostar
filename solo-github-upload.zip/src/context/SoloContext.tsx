import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import { applyThemeCssVariables, THEME_ORDER, THEMES } from '../config/themes';
import { soundEngine } from '../services/soundEngine';
import { storage } from '../services/storage';
import type {
  SfxKind,
  SoundPreferences,
  ThemeConfig,
  ThemeId,
} from '../types/solo';

const THEME_STORAGE_KEY = 'solo_theme_id';
const AUTO_ROTATE_KEY = 'solo_theme_auto_rotate';
const ROTATE_INTERVAL_KEY = 'solo_theme_interval_sec';
const SOUND_PREFS_KEY = 'solo_sound_prefs';

const DEFAULT_SOUND_PREFS: SoundPreferences = {
  masterEnabled: false, // Never autoplay before explicit user interaction
  ambientEnabled: true,
  sfxEnabled: true,
  ambientVolume: 0.4,
  sfxVolume: 0.45,
};

interface SoloContextValue {
  theme: ThemeConfig;
  themeId: ThemeId;
  autoRotate: boolean;
  rotationIntervalSec: number;
  secondsRemaining: number;
  setTheme: (id: ThemeId, userInitiated?: boolean) => void;
  toggleAutoRotate: () => void;
  setRotationIntervalSec: (sec: number) => void;
  soundPrefs: SoundPreferences;
  toggleMasterSound: () => void;
  toggleAmbient: () => void;
  toggleSfx: () => void;
  setAmbientVolume: (vol: number) => void;
  setSfxVolume: (vol: number) => void;
  playSfx: (kind: SfxKind) => void;
  isReducedMotion: boolean;
  isLowPowerDevice: boolean;
  activeSection: string;
  setActiveSection: (id: string) => void;
}

const SoloContext = createContext<SoloContextValue | null>(null);

export const SoloProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [themeId, setThemeId] = useState<ThemeId>(() => {
    const saved = storage.get<ThemeId>(THEME_STORAGE_KEY, 'royal-purple');
    return THEMES[saved] ? saved : 'royal-purple';
  });

  const [autoRotate, setAutoRotate] = useState<boolean>(() =>
    storage.get<boolean>(AUTO_ROTATE_KEY, false)
  );

  const [rotationIntervalSec, setRotationIntervalSecState] = useState<number>(
    () => {
      const saved = storage.get<number>(ROTATE_INTERVAL_KEY, 40);
      return Math.min(60, Math.max(30, saved));
    }
  );

  const [secondsRemaining, setSecondsRemaining] = useState<number>(
    rotationIntervalSec
  );

  const [soundPrefs, setSoundPrefs] = useState<SoundPreferences>(() => {
    const saved = storage.get<SoundPreferences>(
      SOUND_PREFS_KEY,
      DEFAULT_SOUND_PREFS
    );
    // Always start muted until visitor clicks to enable audio
    return {
      ...DEFAULT_SOUND_PREFS,
      ...saved,
      masterEnabled: false,
    };
  });

  const [isReducedMotion, setIsReducedMotion] = useState<boolean>(false);
  const [isLowPowerDevice, setIsLowPowerDevice] = useState<boolean>(false);
  const [activeSection, setActiveSection] = useState<string>('home');

  const theme = THEMES[themeId];

  // Detect accessibility motion & device capabilities
  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    setIsReducedMotion(mq.matches);
    const onChange = (e: MediaQueryListEvent) => setIsReducedMotion(e.matches);
    mq.addEventListener('change', onChange);

    const cores = navigator.hardwareConcurrency ?? 8;
    const isSmall = window.innerWidth < 768;
    setIsLowPowerDevice(cores <= 4 || isSmall);

    return () => mq.removeEventListener('change', onChange);
  }, []);

  // Apply CSS custom properties whenever theme changes
  useEffect(() => {
    applyThemeCssVariables(theme);
    soundEngine.updateAmbientRoot(theme.harmonicRootHz);
  }, [theme]);

  // Persist theme & rotation settings
  useEffect(() => {
    storage.set(THEME_STORAGE_KEY, themeId);
  }, [themeId]);

  useEffect(() => {
    storage.set(AUTO_ROTATE_KEY, autoRotate);
  }, [autoRotate]);

  useEffect(() => {
    storage.set(ROTATE_INTERVAL_KEY, rotationIntervalSec);
  }, [rotationIntervalSec]);

  // Automatic theme rotation every 30-60s when enabled
  useEffect(() => {
    if (!autoRotate) {
      setSecondsRemaining(rotationIntervalSec);
      return;
    }

    setSecondsRemaining(rotationIntervalSec);
    const timer = window.setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          setThemeId((current) => {
            const idx = THEME_ORDER.indexOf(current);
            const next = THEME_ORDER[(idx + 1) % THEME_ORDER.length];
            return next;
          });
          return rotationIntervalSec;
        }
        return prev - 1;
      });
    }, 1000);

    return () => window.clearInterval(timer);
  }, [autoRotate, rotationIntervalSec]);

  const setTheme = useCallback(
    (id: ThemeId, userInitiated = true) => {
      if (!THEMES[id]) return;
      setThemeId(id);
      setSecondsRemaining(rotationIntervalSec);
      if (userInitiated) {
        soundEngine.playSfx('theme');
      }
    },
    [rotationIntervalSec]
  );

  const toggleAutoRotate = useCallback(() => {
    setAutoRotate((prev) => !prev);
    soundEngine.playSfx('click');
  }, []);

  const setRotationIntervalSec = useCallback((sec: number) => {
    const clamped = Math.min(60, Math.max(30, sec));
    setRotationIntervalSecState(clamped);
    setSecondsRemaining(clamped);
  }, []);

  const persistSound = useCallback(
    (updater: (prev: SoundPreferences) => SoundPreferences, fromGesture = false) => {
      setSoundPrefs((prev) => {
        const next = updater(prev);
        storage.set(SOUND_PREFS_KEY, {
          ...next,
          masterEnabled: false, // Never store unmuted autoplay across fresh reloads
        });
        if (fromGesture) {
          soundEngine.activateFromUserGesture(next, theme.harmonicRootHz);
        } else {
          soundEngine.syncPreferences(next, theme.harmonicRootHz);
        }
        return next;
      });
    },
    [theme.harmonicRootHz]
  );

  const toggleMasterSound = useCallback(() => {
    persistSound((prev) => {
      const enabling = !prev.masterEnabled;
      const next = { ...prev, masterEnabled: enabling };
      if (enabling) {
        window.setTimeout(() => soundEngine.playSfx('menuOpen'), 40);
      }
      return next;
    }, true);
  }, [persistSound]);

  const toggleAmbient = useCallback(() => {
    persistSound((prev) => ({
      ...prev,
      ambientEnabled: !prev.ambientEnabled,
    }), true);
    soundEngine.playSfx('click');
  }, [persistSound]);

  const toggleSfx = useCallback(() => {
    persistSound((prev) => ({
      ...prev,
      sfxEnabled: !prev.sfxEnabled,
    }), true);
  }, [persistSound]);

  const setAmbientVolume = useCallback(
    (vol: number) => {
      const clamped = Math.min(1, Math.max(0, vol));
      persistSound((prev) => ({ ...prev, ambientVolume: clamped }));
    },
    [persistSound]
  );

  const setSfxVolume = useCallback(
    (vol: number) => {
      const clamped = Math.min(1, Math.max(0, vol));
      persistSound((prev) => ({ ...prev, sfxVolume: clamped }));
    },
    [persistSound]
  );

  const playSfx = useCallback((kind: SfxKind) => {
    soundEngine.playSfx(kind);
  }, []);

  const value = useMemo<SoloContextValue>(
    () => ({
      theme,
      themeId,
      autoRotate,
      rotationIntervalSec,
      secondsRemaining,
      setTheme,
      toggleAutoRotate,
      setRotationIntervalSec,
      soundPrefs,
      toggleMasterSound,
      toggleAmbient,
      toggleSfx,
      setAmbientVolume,
      setSfxVolume,
      playSfx,
      isReducedMotion,
      isLowPowerDevice,
      activeSection,
      setActiveSection,
    }),
    [
      theme,
      themeId,
      autoRotate,
      rotationIntervalSec,
      secondsRemaining,
      setTheme,
      toggleAutoRotate,
      setRotationIntervalSec,
      soundPrefs,
      toggleMasterSound,
      toggleAmbient,
      toggleSfx,
      setAmbientVolume,
      setSfxVolume,
      playSfx,
      isReducedMotion,
      isLowPowerDevice,
      activeSection,
    ]
  );

  return <SoloContext.Provider value={value}>{children}</SoloContext.Provider>;
};

export function useSolo(): SoloContextValue {
  const ctx = useContext(SoloContext);
  if (!ctx) {
    throw new Error('useSolo must be used inside SoloProvider');
  }
  return ctx;
}
