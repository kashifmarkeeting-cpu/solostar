import React, { useEffect, useRef, useState } from 'react';
import { useSolo } from '../context/SoloContext';

export const CustomCursor: React.FC = () => {
  const { theme, isReducedMotion } = useSolo();
  const [enabled, setEnabled] = useState(false);
  const [isHoveringInteractive, setIsHoveringInteractive] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  const ringRef = useRef<HTMLDivElement | null>(null);
  const dotRef = useRef<HTMLDivElement | null>(null);
  const pos = useRef({ x: -100, y: -100, rx: -100, ry: -100 });

  useEffect(() => {
    if (isReducedMotion) {
      setEnabled(false);
      return;
    }

    const finePointer = window.matchMedia('(pointer: fine)').matches;
    if (!finePointer) {
      setEnabled(false);
      return;
    }
    setEnabled(true);

    let rafId = 0;

    const onMove = (e: MouseEvent) => {
      pos.current.x = e.clientX;
      pos.current.y = e.clientY;
      setIsVisible(true);

      const target = e.target as HTMLElement | null;
      const interactive = target?.closest(
        'a, button, input, textarea, select, [role="button"], [data-interactive="true"]'
      );
      setIsHoveringInteractive(Boolean(interactive));
    };

    const onLeave = () => setIsVisible(false);

    const animate = () => {
      pos.current.rx += (pos.current.x - pos.current.rx) * 0.18;
      pos.current.ry += (pos.current.y - pos.current.ry) * 0.18;

      if (dotRef.current) {
        dotRef.current.style.transform = `translate3d(${pos.current.x}px, ${pos.current.y}px, 0) translate(-50%, -50%)`;
      }
      if (ringRef.current) {
        const scale = isHoveringInteractive ? 1.45 : 1;
        ringRef.current.style.transform = `translate3d(${pos.current.rx}px, ${pos.current.ry}px, 0) translate(-50%, -50%) scale(${scale})`;
      }

      rafId = requestAnimationFrame(animate);
    };

    window.addEventListener('mousemove', onMove, { passive: true });
    document.addEventListener('mouseleave', onLeave);
    rafId = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseleave', onLeave);
    };
  }, [isReducedMotion, isHoveringInteractive]);

  if (!enabled || !isVisible) return null;

  return (
    <div className="pointer-events-none fixed inset-0 z-[90]" aria-hidden="true">
      <div
        ref={ringRef}
        className="fixed top-0 left-0 h-8 w-8 rounded-full border transition-[border-color,opacity] duration-200"
        style={{
          borderColor: isHoveringInteractive
            ? theme.accentBright
            : theme.border,
          boxShadow: isHoveringInteractive ? `0 0 18px ${theme.glow}` : 'none',
          opacity: 0.85,
        }}
      />
      <div
        ref={dotRef}
        className="fixed top-0 left-0 h-1.5 w-1.5 rounded-full"
        style={{
          backgroundColor: theme.accentBright,
        }}
      />
    </div>
  );
};
