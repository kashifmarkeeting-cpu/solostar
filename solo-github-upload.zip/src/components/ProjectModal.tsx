import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, Layers, X } from 'lucide-react';
import { useSolo } from '../context/SoloContext';
import type { ProjectItem } from '../types/solo';
import { MagneticButton } from './MagneticButton';

interface ProjectModalProps {
  project: ProjectItem | null;
  onClose: () => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({
  project,
  onClose,
}) => {
  const { theme, playSfx } = useSolo();
  const [imgError, setImgError] = useState(false);

  useEffect(() => {
    setImgError(false);
  }, [project?.id]);

  useEffect(() => {
    if (!project) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        playSfx('menuClose');
        onClose();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [project, onClose, playSfx]);

  return (
    <AnimatePresence>
      {project && (
        <div className="fixed inset-0 z-[95] flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => {
              playSfx('menuClose');
              onClose();
            }}
            className="fixed inset-0 bg-black/80 backdrop-blur-md"
          />

          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 12, scale: 0.98 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            role="dialog"
            aria-modal="true"
            aria-label={project.title}
            className="relative z-10 w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-2xl border shadow-2xl"
            style={{
              backgroundColor: 'var(--solo-surface)',
              borderColor: 'var(--solo-border)',
            }}
          >
            {/* Top Bar */}
            <div className="sticky top-0 z-20 flex items-center justify-between gap-4 px-6 py-4 border-b border-[var(--solo-border-subtle)] backdrop-blur-md bg-[var(--solo-surface)]/90">
              <div className="flex items-center gap-2 text-xs text-[var(--solo-text-muted)]">
                <span style={{ color: theme.accentBright }}>
                  {project.category}
                </span>
                <span aria-hidden="true">·</span>
                <span className="font-mono-tabular">{project.year}</span>
              </div>

              <button
                type="button"
                onClick={() => {
                  playSfx('menuClose');
                  onClose();
                }}
                aria-label="Close project details"
                className="min-w-[40px] min-h-[40px] inline-flex items-center justify-center rounded-xl border border-[var(--solo-border-subtle)] text-[var(--solo-text-muted)] hover:text-[var(--solo-text)] focus-visible:outline-none focus-visible:ring-2"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Hero Image */}
            <div className="relative aspect-[16/9] w-full overflow-hidden bg-[var(--solo-bg)]">
              {!imgError ? (
                <img
                  src={project.image}
                  alt={project.title}
                  referrerPolicy="no-referrer"
                  onError={() => setImgError(true)}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-sm text-[var(--solo-text-muted)]">
                  {project.title}
                </div>
              )}
              <div
                className="absolute inset-0 pointer-events-none"
                style={{
                  background:
                    'linear-gradient(to top, var(--solo-surface) 2%, transparent 45%)',
                }}
              />
            </div>

            {/* Content */}
            <div className="p-6 sm:p-8 space-y-8">
              <div className="space-y-3">
                <p className="text-xs text-[var(--solo-text-muted)]">
                  {project.conceptStatus}
                </p>
                <h2 className="font-display text-2xl sm:text-3xl font-bold text-[var(--solo-text)]">
                  {project.title}
                </h2>
                <p className="text-base leading-relaxed text-[var(--solo-text-muted)]">
                  {project.description}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-[var(--solo-border-subtle)]">
                <div className="space-y-3">
                  <h3 className="font-display text-sm font-semibold uppercase tracking-wider text-[var(--solo-text)] flex items-center gap-2">
                    <Layers
                      className="w-4 h-4"
                      style={{ color: theme.accentBright }}
                    />
                    <span>Architecture Notes</span>
                  </h3>
                  <ul className="space-y-2.5 text-sm text-[var(--solo-text-muted)]">
                    {project.architectureNotes.map((note) => (
                      <li key={note} className="leading-relaxed">
                        {note}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-4">
                  <div className="space-y-3">
                    <h3 className="font-display text-sm font-semibold uppercase tracking-wider text-[var(--solo-text)]">
                      Key Deliverables
                    </h3>
                    <ul className="space-y-2 text-sm text-[var(--solo-text-muted)]">
                      {project.deliverables.map((item) => (
                        <li key={item} className="flex items-center gap-2">
                          <CheckCircle2
                            className="w-4 h-4 shrink-0"
                            style={{ color: theme.accentBright }}
                          />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="pt-2">
                    <div className="text-xs font-medium text-[var(--solo-text)] mb-1.5">
                      Technologies
                    </div>
                    <div className="text-xs text-[var(--solo-text-muted)] flex flex-wrap items-center gap-x-2 gap-y-1">
                      {project.technologies.map((tech, idx) => (
                        <React.Fragment key={tech}>
                          <span>{tech}</span>
                          {idx < project.technologies.length - 1 && (
                            <span aria-hidden="true">·</span>
                          )}
                        </React.Fragment>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-[var(--solo-border-subtle)] flex flex-wrap items-center justify-between gap-4">
                <MagneticButton
                  variant="primary"
                  onClick={() => {
                    onClose();
                    const el = document.getElementById('contact');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                >
                  Discuss Similar Work
                </MagneticButton>
                <button
                  type="button"
                  onClick={() => {
                    playSfx('menuClose');
                    onClose();
                  }}
                  className="px-4 py-2.5 min-h-[42px] rounded-xl text-sm font-medium border border-[var(--solo-border-subtle)] text-[var(--solo-text-muted)] hover:text-[var(--solo-text)]"
                >
                  Close Preview
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
