import React, { useEffect, useState } from 'react';
import { ArrowUp } from 'lucide-react';
import { useSolo } from '../context/SoloContext';

export const ScrollProgress: React.FC = () => {
  const { theme, playSfx } = useSolo();
  const [progress, setProgress] = useState(0);
  const [showTop, setShowTop] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      const scrollTop = window.scrollY;
      const docHeight =
        document.documentElement.scrollHeight - window.innerHeight;
      const ratio = docHeight > 0 ? Math.min(1, scrollTop / docHeight) : 0;
      setProgress(ratio * 100);
      setShowTop(scrollTop > 520);
    };

    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <>
      <div
        className="fixed top-0 left-0 right-0 z-[60] h-[2px] pointer-events-none"
        aria-hidden="true"
      >
        <div
          className="h-full transition-[width] duration-100"
          style={{
            width: `${progress}%`,
            backgroundColor: theme.accentBright,
            boxShadow: `0 0 10px ${theme.glow}`,
          }}
        />
      </div>

      {showTop && (
        <button
          type="button"
          onClick={() => {
            playSfx('nav');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          aria-label="Back to top"
          className="fixed bottom-5 right-5 z-40 min-w-[44px] min-h-[44px] inline-flex items-center justify-center rounded-xl border shadow-lg backdrop-blur-md transition-transform duration-200 hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2"
          style={{
            backgroundColor: 'var(--solo-surface)',
            borderColor: 'var(--solo-border)',
            color: theme.accentBright,
            boxShadow: `0 8px 24px -6px ${theme.glow}`,
          }}
        >
          <ArrowUp className="w-4 h-4" />
        </button>
      )}
    </>
  );
};
