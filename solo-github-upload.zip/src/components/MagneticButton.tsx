import React, { useRef, useState } from 'react';
import { useSolo } from '../context/SoloContext';
import type { SfxKind } from '../types/solo';

interface MagneticButtonProps {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'ghost';
  href?: string;
  onClick?: (e: React.MouseEvent<HTMLElement>) => void;
  className?: string;
  sfx?: SfxKind;
  type?: 'button' | 'submit' | 'reset';
  disabled?: boolean;
  ariaLabel?: string;
}

export const MagneticButton: React.FC<MagneticButtonProps> = ({
  children,
  variant = 'primary',
  href,
  onClick,
  className = '',
  sfx = 'click',
  type = 'button',
  disabled = false,
  ariaLabel,
}) => {
  const { theme, playSfx, isReducedMotion } = useSolo();
  const ref = useRef<HTMLElement | null>(null);
  const [offset, setOffset] = useState({ x: 0, y: 0 });

  const handlePointerMove = (e: React.PointerEvent<HTMLElement>) => {
    if (isReducedMotion || disabled || e.pointerType !== 'mouse') return;
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const dx = e.clientX - (rect.left + rect.width / 2);
    const dy = e.clientY - (rect.top + rect.height / 2);
    setOffset({ x: dx * 0.14, y: dy * 0.18 });
  };

  const handlePointerLeave = () => {
    setOffset({ x: 0, y: 0 });
  };

  const handleClick = (e: React.MouseEvent<HTMLElement>) => {
    if (disabled) return;
    playSfx(sfx);
    onClick?.(e);
  };

  const baseStyles =
    'relative inline-flex items-center justify-center gap-2.5 px-6 py-3 min-h-[44px] rounded-xl text-sm font-semibold tracking-wide whitespace-nowrap shrink-0 transition-[transform,box-shadow,background-color,border-color,color] duration-200 ease-[cubic-bezier(0.16,1,0.3,1)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-[#07050c] disabled:opacity-50 disabled:cursor-not-allowed';

  const variantStyle: React.CSSProperties =
    variant === 'primary'
      ? {
          backgroundColor: theme.accent,
          color: '#ffffff',
          boxShadow: `0 8px 28px -6px ${theme.glow}`,
          border: `1px solid ${theme.accentBright}`,
        }
      : variant === 'secondary'
      ? {
          backgroundColor: 'var(--solo-surface)',
          color: 'var(--solo-text)',
          border: `1px solid var(--solo-border)`,
        }
      : {
          backgroundColor: 'transparent',
          color: 'var(--solo-text-muted)',
          border: '1px solid transparent',
        };

  const style: React.CSSProperties = {
    ...variantStyle,
    transform: `translate3d(${offset.x}px, ${offset.y}px, 0)`,
  };

  if (href) {
    return (
      <a
        ref={ref as React.RefObject<HTMLAnchorElement>}
        href={href}
        onClick={handleClick}
        onPointerMove={handlePointerMove}
        onPointerLeave={handlePointerLeave}
        style={style}
        aria-label={ariaLabel}
        className={`${baseStyles} hover:brightness-110 active:scale-[0.98] ${className}`}
      >
        {children}
      </a>
    );
  }

  return (
    <button
      ref={ref as React.RefObject<HTMLButtonElement>}
      type={type}
      disabled={disabled}
      onClick={handleClick}
      onPointerMove={handlePointerMove}
      onPointerLeave={handlePointerLeave}
      style={style}
      aria-label={ariaLabel}
      className={`${baseStyles} hover:brightness-110 active:scale-[0.98] ${className}`}
    >
      {children}
    </button>
  );
};
