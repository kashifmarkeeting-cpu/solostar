import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useSolo } from '../context/SoloContext';
import { BrandMark } from './BrandMark';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const { theme, isReducedMotion } = useSolo();
  const [visible, setVisible] = useState(true);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (isReducedMotion) {
      setVisible(false);
      onComplete();
      return;
    }

    const start = performance.now();
    const duration = 1150;
    let rafId = 0;

    const tick = (now: number) => {
      const elapsed = now - start;
      const pct = Math.min(100, Math.round((elapsed / duration) * 100));
      setProgress(pct);
      if (elapsed < duration) {
        rafId = requestAnimationFrame(tick);
      } else {
        setVisible(false);
        window.setTimeout(onComplete, 320);
      }
    };

    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [isReducedMotion, onComplete]);

  const handleSkip = () => {
    setVisible(false);
    onComplete();
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.35, ease: [0.16, 1, 0.3, 1] } }}
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center px-6"
          style={{ backgroundColor: 'var(--solo-bg)' }}
          role="dialog"
          aria-label="Initializing SOLO digital experience"
        >
          <div
            className="absolute inset-0 pointer-events-none opacity-45"
            style={{
              background: `radial-gradient(circle at 50% 45%, ${theme.glow} 0%, transparent 55%)`,
            }}
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.92, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
            className="relative z-10 flex flex-col items-center gap-6 text-center"
          >
            <BrandMark size="lg" showWordmark={false} />

            <div className="space-y-1.5">
              <div className="font-display text-3xl sm:text-4xl font-bold tracking-[0.28em] text-[var(--solo-text)]">
                SOLO
              </div>
              <p className="text-xs tracking-[0.22em] uppercase text-[var(--solo-text-muted)]">
                Digital Identity
              </p>
            </div>

            <div className="w-56 space-y-2">
              <div
                className="h-0.5 w-full overflow-hidden rounded-full"
                style={{ backgroundColor: 'var(--solo-border-subtle)' }}
              >
                <div
                  className="h-full transition-[width] duration-75"
                  style={{
                    width: `${progress}%`,
                    backgroundColor: theme.accentBright,
                    boxShadow: `0 0 12px ${theme.glow}`,
                  }}
                />
              </div>
              <div className="flex items-center justify-between text-[11px] font-mono-tabular text-[var(--solo-text-muted)]">
                <span>Preparing Experience</span>
                <span>{progress}%</span>
              </div>
            </div>

            <button
              type="button"
              onClick={handleSkip}
              className="mt-2 px-4 py-2 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap focus-visible:outline-none focus-visible:ring-2"
              style={{
                borderColor: 'var(--solo-border)',
                color: 'var(--solo-text-muted)',
              }}
            >
              Enter Directly
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
