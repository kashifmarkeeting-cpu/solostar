import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'motion/react';
import {
  ArrowDown,
  ArrowRight,
  Compass,
  Github,
  Instagram,
  Linkedin,
  Send,
  Sparkles,
} from 'lucide-react';
import { THEME_ORDER, THEMES } from '../config/themes';
import { useSolo } from '../context/SoloContext';
import { HERO_COPY, PORTRAIT_SRC, SOCIAL_LINKS } from '../data/portfolioContent';
import { MagneticButton } from './MagneticButton';

export const HeroSection: React.FC = () => {
  const {
    theme,
    themeId,
    setTheme,
    autoRotate,
    secondsRemaining,
    isReducedMotion,
    playSfx,
  } = useSolo();

  const roles = HERO_COPY.roles;
  const [roleIndex, setRoleIndex] = useState(0);
  const [typedText, setTypedText] = useState(roles[0]);
  const [glitching, setGlitching] = useState(false);

  const [localTime, setLocalTime] = useState(() =>
    new Intl.DateTimeFormat(undefined, {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    }).format(new Date())
  );

  const stageRef = useRef<HTMLDivElement | null>(null);
  const [parallax, setParallax] = useState({ x: 0, y: 0 });
  const [imgError, setImgError] = useState(false);

  // Live local clock
  useEffect(() => {
    const id = window.setInterval(() => {
      setLocalTime(
        new Intl.DateTimeFormat(undefined, {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        }).format(new Date())
      );
    }, 1000);
    return () => window.clearInterval(id);
  }, []);

  // Typewriter + controlled glitch role switcher
  useEffect(() => {
    if (isReducedMotion) {
      setTypedText(roles[roleIndex]);
      return;
    }

    const targetRole = roles[roleIndex];
    let charIdx = 0;
    setTypedText('');
    setGlitching(true);
    const glitchReset = window.setTimeout(() => setGlitching(false), 320);

    const typeTimer = window.setInterval(() => {
      charIdx += 1;
      setTypedText(targetRole.slice(0, charIdx));
      if (charIdx >= targetRole.length) {
        window.clearInterval(typeTimer);
      }
    }, 48);

    const nextTimer = window.setTimeout(() => {
      setRoleIndex((prev) => (prev + 1) % roles.length);
    }, 3200);

    return () => {
      window.clearTimeout(glitchReset);
      window.clearInterval(typeTimer);
      window.clearTimeout(nextTimer);
    };
  }, [roleIndex, roles, isReducedMotion]);

  const handlePortraitMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isReducedMotion || e.pointerType !== 'mouse') return;
    const el = stageRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const nx = (e.clientX - rect.left) / rect.width - 0.5;
    const ny = (e.clientY - rect.top) / rect.height - 0.5;
    setParallax({ x: nx * 18, y: ny * 14 });
  };

  const handlePortraitLeave = () => {
    setParallax({ x: 0, y: 0 });
  };

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const socialIcons: Record<string, React.ReactNode> = {
    GitHub: <Github className="w-4 h-4" />,
    'X / Twitter': (
      <span className="text-xs font-bold leading-none" aria-hidden="true">
        𝕏
      </span>
    ),
    Instagram: <Instagram className="w-4 h-4" />,
    LinkedIn: <Linkedin className="w-4 h-4" />,
  };

  return (
    <section
      id="home"
      className="relative min-h-screen flex flex-col justify-between pt-24 pb-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto"
    >
      {/* Main Split Composition */}
      <div className="my-auto grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
        {/* Left Column: Kinetic Typography & CTAs */}
        <div className="lg:col-span-7 space-y-6 z-10 order-2 lg:order-1">
          <motion.div
            initial={isReducedMotion ? false : { opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
            className="space-y-3"
          >
            <p
              className="text-xs sm:text-sm font-medium tracking-[0.2em] uppercase"
              style={{ color: theme.accentBright }}
            >
              {HERO_COPY.intro}
            </p>

            <h1 className="font-display font-extrabold tracking-tight leading-[0.95] text-[var(--solo-text)]">
              <span className="block text-2xl sm:text-3xl lg:text-4xl font-semibold text-[var(--solo-text-muted)] mb-2">
                {HERO_COPY.greeting}
              </span>
              <span
                className="block tracking-[0.06em] theme-transition"
                style={{
                  fontSize: 'clamp(3.6rem, 9vw, 6.8rem)',
                  backgroundImage: `linear-gradient(135deg, #ffffff 15%, ${theme.accentBright} 65%, ${theme.accent} 100%)`,
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  filter: `drop-shadow(0 8px 28px ${theme.glow})`,
                }}
              >
                {HERO_COPY.brand}
              </span>
            </h1>
          </motion.div>

          {/* Animated Dynamic Professional Role */}
          <div className="min-h-[42px] flex items-center gap-3">
            <span
              className="h-px w-8 shrink-0"
              style={{ backgroundColor: theme.accentBright }}
              aria-hidden="true"
            />
            <div
              className={`font-display text-xl sm:text-2xl font-semibold tracking-tight text-[var(--solo-text)] ${
                glitching ? 'animate-glitch-burst' : ''
              }`}
              aria-live="polite"
            >
              <span>{typedText}</span>
              {!isReducedMotion && (
                <span
                  className="inline-block w-[2px] h-[1.05em] ml-1 align-middle"
                  style={{ backgroundColor: theme.accentBright }}
                  aria-hidden="true"
                />
              )}
            </div>
          </div>

          <motion.p
            initial={isReducedMotion ? false : { opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="text-base sm:text-lg leading-relaxed max-w-xl text-[var(--solo-text-muted)]"
          >
            {HERO_COPY.description}
          </motion.p>

          {/* Primary & Secondary CTAs */}
          <motion.div
            initial={isReducedMotion ? false : { opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.18, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-wrap items-center gap-4 pt-2"
          >
            <MagneticButton
              variant="primary"
              onClick={() => scrollTo('projects')}
              sfx="nav"
            >
              <Compass className="w-4 h-4 shrink-0" />
              <span>{HERO_COPY.primaryCta}</span>
              <ArrowRight className="w-4 h-4 shrink-0" />
            </MagneticButton>

            <MagneticButton
              variant="secondary"
              onClick={() => scrollTo('contact')}
              sfx="nav"
            >
              <Send className="w-4 h-4 shrink-0" />
              <span>{HERO_COPY.secondaryCta}</span>
            </MagneticButton>
          </motion.div>

          {/* Interactive Social Links + Honest Studio Label */}
          <div className="pt-4 flex flex-wrap items-center gap-x-6 gap-y-3 text-xs text-[var(--solo-text-muted)]">
            <div className="flex items-center gap-2">
              {SOCIAL_LINKS.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  target="_blank"
                  rel="noreferrer noopener"
                  onClick={() => playSfx('click')}
                  aria-label={`${s.label} (${s.handle})`}
                  className="min-w-[40px] min-h-[40px] inline-flex items-center justify-center rounded-xl border transition-colors duration-200 hover:text-[var(--solo-text)] focus-visible:outline-none focus-visible:ring-2"
                  style={{
                    backgroundColor: 'var(--solo-surface)',
                    borderColor: 'var(--solo-border-subtle)',
                  }}
                >
                  {socialIcons[s.label]}
                </a>
              ))}
            </div>

            <span className="hidden sm:inline text-[var(--solo-border)]" aria-hidden="true">
              |
            </span>

            <div className="flex items-center gap-2">
              <Sparkles
                className="w-3.5 h-3.5 shrink-0"
                style={{ color: theme.accentBright }}
                aria-hidden="true"
              />
              <span>Decorative Studio Status · Open for Creative Projects</span>
            </div>
          </div>
        </div>

        {/* Right Column: Original Portrait Stage with Atmospheric Lighting & Rings */}
        <div
          ref={stageRef}
          onPointerMove={handlePortraitMove}
          onPointerLeave={handlePortraitLeave}
          className="lg:col-span-5 relative flex items-center justify-center order-1 lg:order-2 min-h-[380px] sm:min-h-[470px] lg:min-h-[560px]"
        >
          {/* Ambient Volumetric Light Backdrop */}
          <div
            className="absolute inset-4 rounded-full blur-3xl opacity-55 pointer-events-none theme-transition"
            style={{
              background: `radial-gradient(circle at 50% 45%, ${theme.glow}, transparent 68%)`,
              transform: `translate3d(${parallax.x * -0.6}px, ${parallax.y * -0.6}px, 0)`,
            }}
            aria-hidden="true"
          />

          {/* Concentric Animated Energy Rings Behind Subject */}
          <div
            className="absolute w-[300px] h-[300px] sm:w-[390px] sm:h-[390px] lg:w-[440px] lg:h-[440px] rounded-full border pointer-events-none animate-orbit-slow theme-transition"
            style={{
              borderColor: 'var(--solo-border)',
              borderStyle: 'dashed',
              transform: `translate3d(${parallax.x * -0.35}px, ${parallax.y * -0.35}px, 0)`,
            }}
            aria-hidden="true"
          >
            <span
              className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full"
              style={{
                backgroundColor: theme.accentBright,
                boxShadow: `0 0 14px ${theme.glow}`,
              }}
            />
          </div>

          <div
            className="absolute w-[240px] h-[240px] sm:w-[310px] sm:h-[310px] lg:w-[350px] lg:h-[350px] rounded-full border pointer-events-none animate-orbit-reverse theme-transition"
            style={{
              borderColor: 'var(--solo-border-subtle)',
              boxShadow: `inset 0 0 48px -12px ${theme.glow}`,
            }}
            aria-hidden="true"
          />

          {/* Subtle Diagonal Volumetric Light Shafts */}
          <div
            className="absolute inset-x-10 top-6 bottom-12 pointer-events-none opacity-45 theme-transition"
            style={{
              background: `conic-gradient(from 195deg at 50% 15%, transparent 0deg, ${theme.accentMuted} 28deg, transparent 58deg)`,
              filter: 'blur(20px)',
            }}
            aria-hidden="true"
          />

          {/* Subtle Technical Framing Coordinates (Top-Left & Bottom-Right of Portrait Frame) */}
          <div
            className="hidden sm:flex absolute top-4 left-2 lg:left-0 px-3 py-1.5 rounded-lg border text-[11px] font-mono-tabular backdrop-blur-md z-20"
            style={{
              backgroundColor: 'color-mix(in srgb, var(--solo-surface) 78%, transparent)',
              borderColor: 'var(--solo-border)',
              color: 'var(--solo-text-muted)',
            }}
          >
            SOLO · {theme.name}
          </div>

          <div
            className="hidden sm:flex absolute bottom-10 right-2 lg:right-0 px-3 py-1.5 rounded-lg border text-[11px] font-mono-tabular backdrop-blur-md z-20"
            style={{
              backgroundColor: 'color-mix(in srgb, var(--solo-surface) 78%, transparent)',
              borderColor: 'var(--solo-border)',
              color: 'var(--solo-text)',
            }}
          >
            {localTime}
          </div>

          {/* Exact Original Portrait — Uncropped, Proportions Preserved */}
          <motion.div
            initial={isReducedMotion ? false : { opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="relative z-10 w-full max-w-[330px] sm:max-w-[400px] lg:max-w-[440px] flex items-end justify-center"
            style={{
              transform: `translate3d(${parallax.x}px, ${parallax.y}px, 0)`,
              transition: 'transform 220ms cubic-bezier(0.16, 1, 0.3, 1)',
            }}
          >
            {!imgError ? (
              <div className="relative w-full">
                <img
                  src={PORTRAIT_SRC}
                  alt="Portrait of SOLO wearing sunglasses and earphones"
                  referrerPolicy="no-referrer"
                  onError={() => setImgError(true)}
                  className="w-full h-auto object-contain select-none theme-transition"
                  style={{
                    filter: `drop-shadow(0 0 18px ${theme.glow}) drop-shadow(0 14px 36px rgba(0, 0, 0, 0.85))`,
                  }}
                />
                {/* Soft atmospheric bottom edge blend into canvas */}
                <div
                  className="absolute inset-x-0 bottom-0 h-16 pointer-events-none theme-transition"
                  style={{
                    background:
                      'linear-gradient(to top, var(--solo-bg) 8%, transparent 100%)',
                  }}
                  aria-hidden="true"
                />
              </div>
            ) : (
              <div
                className="w-full aspect-[4/5] rounded-2xl border flex flex-col items-center justify-center p-6 text-center"
                style={{
                  backgroundColor: 'var(--solo-surface)',
                  borderColor: 'var(--solo-border)',
                }}
              >
                <span className="font-display text-3xl font-bold text-[var(--solo-text)]">
                  SOLO
                </span>
                <span className="mt-2 text-xs text-[var(--solo-text-muted)]">
                  Digital Identity Portrait
                </span>
              </div>
            )}
          </motion.div>
        </div>
      </div>

      {/* Full-Width Bottom Studio Strip: Quick 4-Theme Selector & Scroll Cue */}
      <div className="mt-10 pt-6 border-t border-[var(--solo-border-subtle)] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 z-10">
        <div
          className="flex flex-wrap items-center gap-1.5 p-1 rounded-xl border"
          style={{
            backgroundColor: 'var(--solo-surface)',
            borderColor: 'var(--solo-border-subtle)',
          }}
          role="group"
          aria-label="Quick color theme switcher"
        >
          {THEME_ORDER.map((id) => {
            const t = THEMES[id];
            const active = id === themeId;
            return (
              <button
                key={id}
                type="button"
                onClick={() => setTheme(id, true)}
                className="inline-flex items-center gap-2 px-3 py-1.5 min-h-[36px] rounded-lg text-xs font-medium whitespace-nowrap shrink-0 transition-all duration-200 focus-visible:outline-none focus-visible:ring-2"
                style={{
                  backgroundColor: active
                    ? 'var(--solo-surface-elevated)'
                    : 'transparent',
                  color: active ? 'var(--solo-text)' : 'var(--solo-text-muted)',
                  border: active
                    ? `1px solid ${t.border}`
                    : '1px solid transparent',
                }}
              >
                <span
                  className="w-2.5 h-2.5 rounded-full shrink-0"
                  style={{ background: t.swatchGradient }}
                  aria-hidden="true"
                />
                <span>{t.name}</span>
              </button>
            );
          })}
          {autoRotate && (
            <span className="px-2.5 text-[11px] font-mono-tabular text-[var(--solo-text-muted)] whitespace-nowrap">
              Auto · {secondsRemaining}s
            </span>
          )}
        </div>

        <button
          type="button"
          onClick={() => {
            playSfx('nav');
            scrollTo('about');
          }}
          className="inline-flex items-center gap-2 text-xs font-medium tracking-wider uppercase text-[var(--solo-text-muted)] hover:text-[var(--solo-text)] transition-colors min-h-[40px] focus-visible:outline-none focus-visible:ring-2 rounded-lg px-2"
        >
          <span>Scroll to Explore</span>
          <ArrowDown
            className="w-4 h-4"
            style={{ color: theme.accentBright }}
          />
        </button>
      </div>
    </section>
  );
};
