import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowUpRight } from 'lucide-react';
import { useSolo } from '../context/SoloContext';
import { PROJECTS } from '../data/portfolioContent';
import type { ProjectItem } from '../types/solo';
import { ProjectModal } from './ProjectModal';

const FILTERS: Array<'All' | ProjectItem['category']> = [
  'All',
  'Interactive',
  'Design Systems',
  'Spatial & WebGL',
];

export const ProjectsSection: React.FC = () => {
  const { theme, isReducedMotion, playSfx } = useSolo();
  const [filter, setFilter] = useState<'All' | ProjectItem['category']>('All');
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(
    null
  );
  const [brokenImages, setBrokenImages] = useState<Record<string, boolean>>({});

  const visibleProjects =
    filter === 'All'
      ? PROJECTS
      : PROJECTS.filter((p) => p.category === filter);

  return (
    <section
      id="projects"
      className="relative py-20 sm:py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto"
    >
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-10">
        <div className="space-y-3 max-w-2xl">
          <p
            className="text-xs font-semibold tracking-[0.2em] uppercase"
            style={{ color: theme.accentBright }}
          >
            Selected Showcase
          </p>
          <h2
            className="font-display font-bold tracking-tight text-[var(--solo-text)]"
            style={{ fontSize: 'clamp(2rem, 4vw, 3rem)' }}
          >
            Featured Digital Worlds.
          </h2>
        </div>

        {/* Interactive Filter Tabs */}
        <div
          className="flex flex-wrap items-center gap-1.5 p-1 rounded-xl border self-start lg:self-auto"
          style={{
            backgroundColor: 'var(--solo-surface)',
            borderColor: 'var(--solo-border-subtle)',
          }}
          role="group"
          aria-label="Filter projects by discipline"
        >
          {FILTERS.map((cat) => {
            const active = filter === cat;
            return (
              <button
                key={cat}
                type="button"
                onClick={() => {
                  playSfx('click');
                  setFilter(cat);
                }}
                className="px-3.5 py-2 min-h-[38px] rounded-lg text-xs font-medium whitespace-nowrap shrink-0 transition-colors focus-visible:outline-none focus-visible:ring-2"
                style={{
                  backgroundColor: active
                    ? 'var(--solo-surface-elevated)'
                    : 'transparent',
                  color: active
                    ? 'var(--solo-text)'
                    : 'var(--solo-text-muted)',
                  border: active
                    ? `1px solid ${theme.border}`
                    : '1px solid transparent',
                }}
              >
                {cat}
              </button>
            );
          })}
        </div>
      </div>

      {/* Bento / Showcase Project Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {visibleProjects.map((project, idx) => {
          const isWide = idx === 0 && visibleProjects.length >= 3;
          return (
            <motion.article
              key={project.id}
              initial={isReducedMotion ? false : { opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{
                duration: 0.5,
                delay: idx * 0.08,
                ease: [0.16, 1, 0.3, 1],
              }}
              onClick={() => {
                playSfx('menuOpen');
                setSelectedProject(project);
              }}
              data-interactive="true"
              className={`group cursor-pointer rounded-2xl border overflow-hidden flex flex-col justify-between transition-all duration-300 hover:-translate-y-1 theme-transition ${
                isWide ? 'md:col-span-2' : ''
              }`}
              style={{
                backgroundColor: 'var(--solo-surface)',
                borderColor: 'var(--solo-border-subtle)',
              }}
            >
              {/* Media Frame */}
              <div
                className={`relative overflow-hidden bg-[var(--solo-bg)] ${
                  isWide ? 'aspect-[16/9] md:aspect-[21/9]' : 'aspect-[4/3]'
                }`}
              >
                {!brokenImages[project.id] ? (
                  <img
                    src={project.image}
                    alt={project.title}
                    loading="lazy"
                    referrerPolicy="no-referrer"
                    onError={() =>
                      setBrokenImages((prev) => ({
                        ...prev,
                        [project.id]: true,
                      }))
                    }
                    className="w-full h-full object-cover transition-transform duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-105"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center">
                    <span className="font-display text-xl font-semibold text-[var(--solo-text)]">
                      {project.title}
                    </span>
                    <span className="mt-1 text-xs text-[var(--solo-text-muted)]">
                      {project.category}
                    </span>
                  </div>
                )}

                {/* Measured Gradient Scrim + Theme Rim Overlay */}
                <div
                  className="absolute inset-0 transition-opacity duration-300 opacity-75 group-hover:opacity-90"
                  style={{
                    background: `linear-gradient(to top, var(--solo-surface) 4%, rgba(0,0,0,0.28) 55%, transparent 100%)`,
                  }}
                />
                <div
                  className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
                  style={{
                    boxShadow: `inset 0 0 60px -15px ${theme.glow}`,
                  }}
                />
              </div>

              {/* Project Body */}
              <div className="p-6 sm:p-7 flex flex-col gap-4">
                <div className="flex items-center justify-between gap-4 text-xs text-[var(--solo-text-muted)]">
                  <span>
                    {project.category} · {project.year}
                  </span>
                  <span className="font-mono-tabular">
                    Concept Showcase
                  </span>
                </div>

                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-2">
                    <h3 className="font-display text-xl sm:text-2xl font-bold text-[var(--solo-text)] group-hover:text-[var(--solo-accent-bright)] transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-sm sm:text-base leading-relaxed text-[var(--solo-text-muted)] max-w-2xl">
                      {project.summary}
                    </p>
                  </div>
                </div>

                <div className="pt-3 border-t border-[var(--solo-border-subtle)] flex flex-wrap items-center justify-between gap-4">
                  {/* Unboxed Tech Tags */}
                  <div className="text-xs text-[var(--solo-text-muted)] flex flex-wrap items-center gap-x-2 gap-y-1">
                    {project.technologies.map((tech, tIdx) => (
                      <React.Fragment key={tech}>
                        <span>{tech}</span>
                        {tIdx < project.technologies.length - 1 && (
                          <span aria-hidden="true">·</span>
                        )}
                      </React.Fragment>
                    ))}
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      playSfx('menuOpen');
                      setSelectedProject(project);
                    }}
                    className="inline-flex items-center gap-1.5 text-sm font-semibold whitespace-nowrap shrink-0 min-h-[38px] px-3 py-1.5 rounded-lg transition-colors focus-visible:outline-none focus-visible:ring-2"
                    style={{
                      color: theme.accentBright,
                      backgroundColor: theme.accentMuted,
                    }}
                  >
                    <span>View Project</span>
                    <ArrowUpRight className="w-4 h-4 shrink-0" />
                  </button>
                </div>
              </div>
            </motion.article>
          );
        })}
      </div>

      <ProjectModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
      />
    </section>
  );
};
