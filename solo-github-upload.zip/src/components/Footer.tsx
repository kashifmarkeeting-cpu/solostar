import React from 'react';
import { useSolo } from '../context/SoloContext';
import { BrandMark } from './BrandMark';
import { PWAInstallButton } from './PWAStatus';

interface FooterProps {
  onShowNotFound: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onShowNotFound }) => {
  const { theme, playSfx } = useSolo();

  const scrollTo = (id: string) => {
    playSfx('nav');
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer
      className="relative border-t py-12 px-4 sm:px-6 lg:px-8"
      style={{
        borderColor: 'var(--solo-border-subtle)',
        backgroundColor: 'var(--solo-surface)',
      }}
    >
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-8">
        <div className="space-y-2.5">
          <BrandMark size="sm" />
          <p className="text-xs text-[var(--solo-text-muted)]">
            Digital Creator · Developer · Creative Mind
          </p>
        </div>

        <nav
          aria-label="Footer Navigation"
          className="flex flex-wrap items-center gap-x-6 gap-y-2 text-xs font-medium text-[var(--solo-text-muted)]"
        >
          {['home', 'about', 'projects', 'skills', 'contact'].map((id) => (
            <button
              key={id}
              type="button"
              onClick={() => scrollTo(id)}
              className="capitalize hover:text-[var(--solo-text)] transition-colors py-1"
            >
              {id}
            </button>
          ))}
          <button
            type="button"
            onClick={() => {
              playSfx('click');
              onShowNotFound();
            }}
            className="hover:text-[var(--solo-text)] transition-colors py-1"
          >
            404 Page
          </button>
        </nav>

        <div className="flex flex-wrap items-center gap-4">
          <PWAInstallButton compact />
          <span className="text-xs text-[var(--solo-text-muted)]">
            © 2026 SOLO · Theme:{' '}
            <span style={{ color: theme.accentBright }}>{theme.name}</span>
          </span>
        </div>
      </div>
    </footer>
  );
};
