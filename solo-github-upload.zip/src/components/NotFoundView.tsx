import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { useSolo } from '../context/SoloContext';
import { BrandMark } from './BrandMark';
import { MagneticButton } from './MagneticButton';

interface NotFoundViewProps {
  onReturnHome: () => void;
}

export const NotFoundView: React.FC<NotFoundViewProps> = ({ onReturnHome }) => {
  const { theme } = useSolo();

  return (
    <main className="relative z-10 min-h-screen flex flex-col items-center justify-center px-6 text-center">
      <div className="max-w-lg space-y-6">
        <div className="flex justify-center">
          <BrandMark size="md" />
        </div>

        <div
          className="font-display font-extrabold tracking-tight leading-none"
          style={{
            fontSize: 'clamp(4.5rem, 14vw, 8rem)',
            color: theme.accentBright,
            textShadow: `0 0 36px ${theme.glow}`,
          }}
        >
          404
        </div>

        <h1 className="font-display text-2xl sm:text-3xl font-bold text-[var(--solo-text)]">
          Destination Outside This World
        </h1>

        <p className="text-sm sm:text-base text-[var(--solo-text-muted)] leading-relaxed">
          The page you requested does not exist or has moved. Return to the main
          SOLO digital identity experience.
        </p>

        <div className="pt-2 flex justify-center">
          <MagneticButton variant="primary" onClick={onReturnHome} sfx="nav">
            <ArrowLeft className="w-4 h-4 shrink-0" />
            <span>Return to SOLO</span>
          </MagneticButton>
        </div>
      </div>
    </main>
  );
};
