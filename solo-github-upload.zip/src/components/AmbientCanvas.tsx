import React, { useEffect, useRef } from 'react';
import { useSolo } from '../context/SoloContext';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  alpha: number;
  colorIndex: number;
}

interface MatrixColumn {
  x: number;
  y: number;
  speed: number;
  length: number;
}

export const AmbientCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const pointerRef = useRef<{ x: number; y: number; active: boolean }>({
    x: 0.5,
    y: 0.35,
    active: false,
  });

  const { theme, isReducedMotion, isLowPowerDevice } = useSolo();

  useEffect(() => {
    if (isReducedMotion) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = window.innerWidth;
    let height = window.innerHeight;
    let dpr = Math.min(window.devicePixelRatio || 1, isLowPowerDevice ? 1 : 1.5);

    const resize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      dpr = Math.min(window.devicePixelRatio || 1, isLowPowerDevice ? 1 : 1.5);
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    resize();

    let resizeTimer: number | undefined;
    const onResize = () => {
      window.clearTimeout(resizeTimer);
      resizeTimer = window.setTimeout(resize, 150);
    };

    const onPointerMove = (e: PointerEvent) => {
      pointerRef.current = {
        x: e.clientX / Math.max(1, width),
        y: e.clientY / Math.max(1, height),
        active: true,
      };
    };

    window.addEventListener('resize', onResize);
    window.addEventListener('pointermove', onPointerMove, { passive: true });

    const particleCount = isLowPowerDevice ? 22 : 48;
    const particles: Particle[] = Array.from({ length: particleCount }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      vx: (Math.random() - 0.5) * 0.28,
      vy: -0.15 - Math.random() * 0.35,
      radius: 1 + Math.random() * 2.2,
      alpha: 0.18 + Math.random() * 0.45,
      colorIndex: Math.floor(Math.random() * theme.particleColors.length),
    }));

    const colStep = isLowPowerDevice ? 64 : 42;
    const matrixCols: MatrixColumn[] = Array.from(
      { length: Math.ceil(width / colStep) },
      (_, i) => ({
        x: i * colStep + 12,
        y: Math.random() * height,
        speed: 0.9 + Math.random() * 1.8,
        length: 60 + Math.random() * 110,
      })
    );

    let rafId = 0;
    let time = 0;

    const render = () => {
      time += 0.012;
      ctx.clearRect(0, 0, width, height);

      const px = pointerRef.current.x * width;
      const py = pointerRef.current.y * height;

      // Subtle cursor-reactive atmospheric halo
      const haloGrad = ctx.createRadialGradient(
        px,
        py,
        0,
        px,
        py,
        Math.max(width, height) * 0.42
      );
      haloGrad.addColorStop(0, theme.smokeColor);
      haloGrad.addColorStop(1, 'transparent');
      ctx.fillStyle = haloGrad;
      ctx.fillRect(0, 0, width, height);

      // Theme-specific atmospheric geometry
      if (theme.motif === 'cyber-grid') {
        const gridSize = 64;
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.055)';
        ctx.lineWidth = 1;
        const offsetY = (time * 18) % gridSize;

        ctx.beginPath();
        for (let x = 0; x < width; x += gridSize) {
          ctx.moveTo(x, 0);
          ctx.lineTo(x, height);
        }
        for (let y = offsetY; y < height; y += gridSize) {
          ctx.moveTo(0, y);
          ctx.lineTo(width, y);
        }
        ctx.stroke();

        // Subtle scanning line
        const scanY = ((time * 55) % (height + 160)) - 80;
        const scanGrad = ctx.createLinearGradient(0, scanY - 40, 0, scanY + 40);
        scanGrad.addColorStop(0, 'transparent');
        scanGrad.addColorStop(0.5, 'rgba(56, 189, 248, 0.09)');
        scanGrad.addColorStop(1, 'transparent');
        ctx.fillStyle = scanGrad;
        ctx.fillRect(0, scanY - 40, width, 80);
      } else if (theme.motif === 'matrix-rain') {
        ctx.lineWidth = 1.25;
        for (const col of matrixCols) {
          col.y += col.speed;
          if (col.y - col.length > height) {
            col.y = -20;
          }
          const grad = ctx.createLinearGradient(col.x, col.y - col.length, col.x, col.y);
          grad.addColorStop(0, 'transparent');
          grad.addColorStop(0.75, 'rgba(74, 222, 128, 0.09)');
          grad.addColorStop(1, 'rgba(132, 204, 22, 0.24)');
          ctx.strokeStyle = grad;
          ctx.beginPath();
          ctx.moveTo(col.x, col.y - col.length);
          ctx.lineTo(col.x, col.y);
          ctx.stroke();
        }
      } else if (theme.motif === 'crimson-beams') {
        // Dramatic diagonal cinematic shafts
        ctx.save();
        ctx.translate(width * 0.72, -100);
        ctx.rotate(0.28 + Math.sin(time * 0.35) * 0.03);
        const beamGrad = ctx.createLinearGradient(0, 0, 0, height * 1.4);
        beamGrad.addColorStop(0, 'rgba(225, 29, 72, 0.14)');
        beamGrad.addColorStop(0.6, 'rgba(225, 29, 72, 0.03)');
        beamGrad.addColorStop(1, 'transparent');
        ctx.fillStyle = beamGrad;
        ctx.fillRect(-140, 0, 280, height * 1.4);
        ctx.restore();
      } else {
        // Royal purple drifting atmospheric mist plumes
        for (let i = 0; i < 3; i++) {
          const cx = width * (0.25 + i * 0.28) + Math.sin(time * 0.4 + i) * 50;
          const cy = height * (0.35 + (i % 2) * 0.25) + Math.cos(time * 0.3 + i) * 40;
          const r = Math.min(width, height) * 0.42;
          const mist = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
          mist.addColorStop(0, theme.smokeColor);
          mist.addColorStop(1, 'transparent');
          ctx.fillStyle = mist;
          ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
        }
      }

      // Floating luminous motes
      for (const p of particles) {
        p.x += p.vx + Math.sin(time + p.y * 0.01) * 0.12;
        p.y += p.vy;

        if (p.y < -12) {
          p.y = height + 12;
          p.x = Math.random() * width;
        }
        if (p.x < -12) p.x = width + 12;
        if (p.x > width + 12) p.x = -12;

        ctx.globalAlpha = p.alpha;
        ctx.fillStyle = theme.particleColors[p.colorIndex % theme.particleColors.length];
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;

      rafId = requestAnimationFrame(render);
    };

    rafId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(rafId);
      window.clearTimeout(resizeTimer);
      window.removeEventListener('resize', onResize);
      window.removeEventListener('pointermove', onPointerMove);
    };
  }, [theme, isReducedMotion, isLowPowerDevice]);

  return (
    <div
      className="fixed inset-0 pointer-events-none z-0 overflow-hidden"
      aria-hidden="true"
    >
      {/* Static / reduced-motion fallback ambient gradient */}
      <div
        className="absolute inset-0 theme-transition"
        style={{
          background: `radial-gradient(ellipse 80% 55% at 70% 20%, ${theme.smokeColor}, transparent 70%), radial-gradient(ellipse 60% 45% at 15% 80%, ${theme.accentMuted}, transparent 70%)`,
        }}
      />
      {!isReducedMotion && (
        <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
      )}
      <div className="absolute inset-0 solo-noise opacity-50 mix-blend-overlay" />
    </div>
  );
};
