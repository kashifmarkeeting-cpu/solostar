import React, { useState } from 'react';
import { Download, WifiOff, X } from 'lucide-react';
import { useSolo } from '../context/SoloContext';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallButton: React.FC<{ compact?: boolean }> = ({
  compact = false,
}) => {
  const { theme, playSfx } = useSolo();
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled) return null;

  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={() => {
          playSfx('click');
          void install();
        }}
        className={`inline-flex items-center justify-center gap-2 rounded-xl font-medium whitespace-nowrap shrink-0 transition-colors min-h-[42px] focus-visible:outline-none focus-visible:ring-2 ${
          compact ? 'px-3.5 py-2 text-xs' : 'w-full px-4 py-2.5 text-sm'
        }`}
        style={{
          backgroundColor: theme.accentMuted,
          color: theme.accentBright,
          border: `1px solid ${theme.border}`,
        }}
      >
        <Download className="w-4 h-4 shrink-0" />
        <span>Install SOLO App</span>
      </button>
    );
  }

  if (isIOS) {
    return (
      <>
        <button
          type="button"
          onClick={() => {
            playSfx('menuOpen');
            setShowIOSGuide(true);
          }}
          className={`inline-flex items-center justify-center gap-2 rounded-xl font-medium whitespace-nowrap shrink-0 transition-colors min-h-[42px] focus-visible:outline-none focus-visible:ring-2 ${
            compact ? 'px-3.5 py-2 text-xs' : 'w-full px-4 py-2.5 text-sm'
          }`}
          style={{
            backgroundColor: theme.accentMuted,
            color: theme.accentBright,
            border: `1px solid ${theme.border}`,
          }}
        >
          <Download className="w-4 h-4 shrink-0" />
          <span>Install on iOS</span>
        </button>

        {showIOSGuide && (
          <div
            className="fixed inset-0 z-[110] flex items-center justify-center bg-black/75 backdrop-blur-sm p-4"
            role="dialog"
            aria-modal="true"
            aria-label="Install SOLO on iOS"
          >
            <div
              className="w-full max-w-sm rounded-2xl p-6 border space-y-4"
              style={{
                backgroundColor: 'var(--solo-surface)',
                borderColor: 'var(--solo-border)',
              }}
            >
              <div className="flex items-center justify-between">
                <h3 className="font-display text-lg font-semibold text-[var(--solo-text)]">
                  Install on iPhone / iPad
                </h3>
                <button
                  type="button"
                  onClick={() => {
                    playSfx('menuClose');
                    setShowIOSGuide(false);
                  }}
                  aria-label="Close install instructions"
                  className="p-2 rounded-lg text-[var(--solo-text-muted)] hover:text-[var(--solo-text)]"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <ol className="space-y-2 text-sm text-[var(--solo-text-muted)] list-decimal list-inside">
                <li>
                  Tap the <strong className="text-[var(--solo-text)]">Share</strong> button in the Safari toolbar.
                </li>
                <li>
                  Scroll down and select{' '}
                  <strong className="text-[var(--solo-text)]">Add to Home Screen</strong>.
                </li>
              </ol>
              <button
                type="button"
                onClick={() => {
                  playSfx('menuClose');
                  setShowIOSGuide(false);
                }}
                className="w-full py-2.5 rounded-xl text-sm font-medium text-white"
                style={{ backgroundColor: theme.accent }}
              >
                Done
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();
  if (isOnline) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed bottom-4 left-4 z-50 flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-medium border shadow-lg backdrop-blur-md"
      style={{
        backgroundColor: 'var(--solo-surface)',
        borderColor: 'var(--solo-border)',
        color: 'var(--solo-text)',
      }}
    >
      <WifiOff className="w-3.5 h-3.5 shrink-0 text-amber-400" />
      <span>Offline Mode — Cached experience active</span>
    </div>
  );
};
