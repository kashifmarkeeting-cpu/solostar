import React, { useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Clock,
  Copy,
  Github,
  Instagram,
  Linkedin,
  Mail,
  Send,
} from 'lucide-react';
import { useSolo } from '../context/SoloContext';
import { SOCIAL_LINKS } from '../data/portfolioContent';
import { MagneticButton } from './MagneticButton';

interface FormErrors {
  name?: string;
  email?: string;
  subject?: string;
  message?: string;
}

export const ContactSection: React.FC = () => {
  const { theme, playSfx } = useSolo();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [honeypot, setHoneypot] = useState(''); // Spam trap
  const mountTimeRef = useRef<number>(Date.now());

  const [errors, setErrors] = useState<FormErrors>({});
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [statusMessage, setStatusMessage] = useState('');
  const [copiedSummary, setCopiedSummary] = useState(false);

  const [localTime, setLocalTime] = useState(() =>
    new Intl.DateTimeFormat(undefined, {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    }).format(new Date())
  );

  useEffect(() => {
    const id = window.setInterval(() => {
      setLocalTime(
        new Intl.DateTimeFormat(undefined, {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        }).format(new Date())
      );
    }, 1000);
    return () => window.clearInterval(id);
  }, []);

  const validate = (): FormErrors => {
    const next: FormErrors = {};
    if (name.trim().length < 2) {
      next.name = 'Please enter your name (at least 2 characters).';
    }
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email.trim())) {
      next.email = 'Please provide a valid email address.';
    }
    if (subject.trim().length < 3) {
      next.subject = 'Please add a short subject for your inquiry.';
    }
    if (message.trim().length < 15) {
      next.message = 'Please share a bit more detail (at least 15 characters).';
    }
    return next;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Spam protection: honeypot check & rapid bot submission check (< 1.5s)
    if (honeypot.trim() !== '') {
      playSfx('error');
      setStatus('error');
      setStatusMessage('Submission rejected by spam filter.');
      return;
    }

    if (Date.now() - mountTimeRef.current < 1500) {
      playSfx('error');
      setStatus('error');
      setStatusMessage('Please take a moment before submitting the form.');
      return;
    }

    const validationErrors = validate();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length > 0) {
      playSfx('error');
      setStatus('error');
      setStatusMessage('Please review the highlighted fields below.');
      return;
    }

    setStatus('submitting');
    window.setTimeout(() => {
      playSfx('success');
      setStatus('success');
      setStatusMessage(
        `Thank you, ${name.trim()}. Your message has been validated and prepared.`
      );
    }, 450);
  };

  const handleCopySummary = async () => {
    const text = `Subject: ${subject}\nFrom: ${name} (${email})\n\n${message}`;
    try {
      await navigator.clipboard.writeText(text);
      playSfx('click');
      setCopiedSummary(true);
      window.setTimeout(() => setCopiedSummary(false), 2400);
    } catch {
      playSfx('error');
    }
  };

  const socialIcon = (label: string) => {
    if (label === 'GitHub') return <Github className="w-4 h-4" />;
    if (label === 'Instagram') return <Instagram className="w-4 h-4" />;
    if (label === 'LinkedIn') return <Linkedin className="w-4 h-4" />;
    return <span className="text-xs font-bold">𝕏</span>;
  };

  return (
    <section
      id="contact"
      className="relative py-20 sm:py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto"
    >
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
        {/* Left Info Column */}
        <div className="lg:col-span-5 space-y-6">
          <div className="space-y-3">
            <p
              className="text-xs font-semibold tracking-[0.2em] uppercase"
              style={{ color: theme.accentBright }}
            >
              Let&apos;s Connect
            </p>
            <h2
              className="font-display font-bold tracking-tight text-[var(--solo-text)]"
              style={{ fontSize: 'clamp(2rem, 4vw, 3rem)' }}
            >
              Build Something Memorable.
            </h2>
          </div>

          <p className="text-base leading-relaxed text-[var(--solo-text-muted)]">
            Whether you are exploring an interactive web experience, a design
            system, or a creative collaboration, send a message and start the
            conversation.
          </p>

          <div
            className="p-5 rounded-2xl border space-y-4"
            style={{
              backgroundColor: 'var(--solo-surface)',
              borderColor: 'var(--solo-border-subtle)',
            }}
          >
            <div className="flex items-center justify-between text-sm">
              <span className="inline-flex items-center gap-2 text-[var(--solo-text-muted)]">
                <Clock className="w-4 h-4" style={{ color: theme.accentBright }} />
                <span>Visitor Local Time</span>
              </span>
              <span className="font-mono-tabular font-medium text-[var(--solo-text)]">
                {localTime}
              </span>
            </div>

            <div className="pt-3 border-t border-[var(--solo-border-subtle)] flex items-center justify-between text-sm">
              <span className="inline-flex items-center gap-2 text-[var(--solo-text-muted)]">
                <Mail className="w-4 h-4" style={{ color: theme.accentBright }} />
                <span>Direct Channels</span>
              </span>
              <span className="text-xs text-[var(--solo-text-muted)]">
                Social & Form
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2.5 pt-1">
              {SOCIAL_LINKS.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  target="_blank"
                  rel="noreferrer noopener"
                  onClick={() => playSfx('click')}
                  className="px-3.5 py-2.5 min-h-[42px] rounded-xl border text-xs font-medium flex items-center gap-2.5 text-[var(--solo-text)] hover:border-[var(--solo-border)] transition-colors focus-visible:outline-none focus-visible:ring-2"
                  style={{
                    backgroundColor: 'var(--solo-bg)',
                    borderColor: 'var(--solo-border-subtle)',
                  }}
                >
                  <span style={{ color: theme.accentBright }}>
                    {socialIcon(s.label)}
                  </span>
                  <span className="truncate">{s.label}</span>
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Right Validated Contact Form */}
        <div className="lg:col-span-7">
          <form
            onSubmit={handleSubmit}
            noValidate
            className="p-6 sm:p-8 rounded-2xl border space-y-5 theme-transition"
            style={{
              backgroundColor: 'var(--solo-surface)',
              borderColor: 'var(--solo-border)',
            }}
          >
            {/* Honeypot spam protection field */}
            <div className="hidden" aria-hidden="true">
              <label htmlFor="solo-website">Website</label>
              <input
                id="solo-website"
                name="website"
                type="text"
                tabIndex={-1}
                autoComplete="off"
                value={honeypot}
                onChange={(e) => setHoneypot(e.target.value)}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div className="space-y-1.5">
                <label
                  htmlFor="contact-name"
                  className="block text-xs font-medium text-[var(--solo-text)]"
                >
                  Your Name
                </label>
                <input
                  id="contact-name"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    if (errors.name) setErrors((p) => ({ ...p, name: undefined }));
                  }}
                  placeholder="Alex Mercer"
                  aria-invalid={Boolean(errors.name)}
                  className="w-full px-4 py-3 min-h-[44px] rounded-xl border text-sm text-[var(--solo-text)] placeholder:text-[var(--solo-text-muted)]/60 focus-visible:outline-none focus-visible:ring-2"
                  style={{
                    backgroundColor: 'var(--solo-bg)',
                    borderColor: errors.name
                      ? '#f43f5e'
                      : 'var(--solo-border-subtle)',
                  }}
                />
                {errors.name && (
                  <p className="text-xs text-rose-400" role="alert">
                    {errors.name}
                  </p>
                )}
              </div>

              <div className="space-y-1.5">
                <label
                  htmlFor="contact-email"
                  className="block text-xs font-medium text-[var(--solo-text)]"
                >
                  Email Address
                </label>
                <input
                  id="contact-email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (errors.email) setErrors((p) => ({ ...p, email: undefined }));
                  }}
                  placeholder="you@domain.com"
                  aria-invalid={Boolean(errors.email)}
                  className="w-full px-4 py-3 min-h-[44px] rounded-xl border text-sm text-[var(--solo-text)] placeholder:text-[var(--solo-text-muted)]/60 focus-visible:outline-none focus-visible:ring-2"
                  style={{
                    backgroundColor: 'var(--solo-bg)',
                    borderColor: errors.email
                      ? '#f43f5e'
                      : 'var(--solo-border-subtle)',
                  }}
                />
                {errors.email && (
                  <p className="text-xs text-rose-400" role="alert">
                    {errors.email}
                  </p>
                )}
              </div>
            </div>

            <div className="space-y-1.5">
              <label
                htmlFor="contact-subject"
                className="block text-xs font-medium text-[var(--solo-text)]"
              >
                Subject
              </label>
              <input
                id="contact-subject"
                type="text"
                required
                value={subject}
                onChange={(e) => {
                  setSubject(e.target.value);
                  if (errors.subject) setErrors((p) => ({ ...p, subject: undefined }));
                }}
                placeholder="Creative Collaboration or Web Project"
                aria-invalid={Boolean(errors.subject)}
                className="w-full px-4 py-3 min-h-[44px] rounded-xl border text-sm text-[var(--solo-text)] placeholder:text-[var(--solo-text-muted)]/60 focus-visible:outline-none focus-visible:ring-2"
                style={{
                  backgroundColor: 'var(--solo-bg)',
                  borderColor: errors.subject
                    ? '#f43f5e'
                    : 'var(--solo-border-subtle)',
                }}
              />
              {errors.subject && (
                <p className="text-xs text-rose-400" role="alert">
                  {errors.subject}
                </p>
              )}
            </div>

            <div className="space-y-1.5">
              <label
                htmlFor="contact-message"
                className="block text-xs font-medium text-[var(--solo-text)]"
              >
                Message
              </label>
              <textarea
                id="contact-message"
                rows={4}
                required
                value={message}
                onChange={(e) => {
                  setMessage(e.target.value);
                  if (errors.message) setErrors((p) => ({ ...p, message: undefined }));
                }}
                placeholder="Tell me about your idea, timeline, or creative vision..."
                aria-invalid={Boolean(errors.message)}
                className="w-full px-4 py-3 rounded-xl border text-sm text-[var(--solo-text)] placeholder:text-[var(--solo-text-muted)]/60 focus-visible:outline-none focus-visible:ring-2 resize-y"
                style={{
                  backgroundColor: 'var(--solo-bg)',
                  borderColor: errors.message
                    ? '#f43f5e'
                    : 'var(--solo-border-subtle)',
                }}
              />
              {errors.message && (
                <p className="text-xs text-rose-400" role="alert">
                  {errors.message}
                </p>
              )}
            </div>

            {/* Status Feedback Banner */}
            {status !== 'idle' && status !== 'submitting' && (
              <div
                role="status"
                aria-live="polite"
                className="p-4 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-sm"
                style={{
                  backgroundColor:
                    status === 'success'
                      ? theme.accentMuted
                      : 'rgba(244, 63, 94, 0.12)',
                  borderColor:
                    status === 'success'
                      ? theme.border
                      : 'rgba(244, 63, 94, 0.35)',
                  color: 'var(--solo-text)',
                }}
              >
                <div className="flex items-start gap-2.5">
                  {status === 'success' ? (
                    <CheckCircle2
                      className="w-4 h-4 mt-0.5 shrink-0"
                      style={{ color: theme.accentBright }}
                    />
                  ) : (
                    <AlertCircle className="w-4 h-4 mt-0.5 shrink-0 text-rose-400" />
                  )}
                  <span>{statusMessage}</span>
                </div>

                {status === 'success' && (
                  <button
                    type="button"
                    onClick={handleCopySummary}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium whitespace-nowrap shrink-0"
                    style={{
                      borderColor: theme.border,
                      backgroundColor: 'var(--solo-surface)',
                    }}
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>{copiedSummary ? 'Copied' : 'Copy Message'}</span>
                  </button>
                )}
              </div>
            )}

            <div className="pt-2 flex flex-wrap items-center justify-between gap-4">
              <span className="text-xs text-[var(--solo-text-muted)]">
                Protected against automated spam · Instant validation
              </span>

              <MagneticButton
                type="submit"
                variant="primary"
                disabled={status === 'submitting'}
                sfx="click"
              >
                <Send className="w-4 h-4 shrink-0" />
                <span>
                  {status === 'submitting' ? 'Sending...' : 'Send Message'}
                </span>
              </MagneticButton>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
};
