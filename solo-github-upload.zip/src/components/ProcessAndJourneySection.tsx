import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Compass, Cpu } from 'lucide-react';
import { useSolo } from '../context/SoloContext';
import {
  JOURNEY_MILESTONES,
  PROCESS_STEPS,
  SERVICES,
  TECH_STACK,
} from '../data/portfolioContent';

export const ProcessAndJourneySection: React.FC = () => {
  const { theme, isReducedMotion, playSfx } = useSolo();
  const [activeStep, setActiveStep] = useState(0);

  return (
    <div className="space-y-24 py-12">
      {/* Services */}
      <section
        id="services"
        className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-10"
      >
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <p
              className="text-xs font-semibold tracking-[0.2em] uppercase"
              style={{ color: theme.accentBright }}
            >
              Services
            </p>
            <h2
              className="font-display font-bold tracking-tight text-[var(--solo-text)]"
              style={{ fontSize: 'clamp(1.85rem, 3.6vw, 2.75rem)' }}
            >
              What I Build.
            </h2>
          </div>
          <p className="text-sm sm:text-base text-[var(--solo-text-muted)] max-w-md">
            Focused capabilities combining visual craft, frontend architecture,
            and mobile-ready engineering.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {SERVICES.map((svc, idx) => (
            <motion.article
              key={svc.index}
              initial={isReducedMotion ? false : { opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{
                duration: 0.45,
                delay: idx * 0.06,
                ease: [0.16, 1, 0.3, 1],
              }}
              className="p-6 sm:p-7 rounded-2xl border flex flex-col justify-between gap-6 theme-transition"
              style={{
                backgroundColor: 'var(--solo-surface)',
                borderColor: 'var(--solo-border-subtle)',
              }}
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span
                    className="font-mono-tabular text-xs font-semibold"
                    style={{ color: theme.accentBright }}
                  >
                    {svc.index}.
                  </span>
                </div>
                <h3 className="font-display text-xl font-semibold text-[var(--solo-text)]">
                  {svc.title}
                </h3>
                <p className="text-sm sm:text-base leading-relaxed text-[var(--solo-text-muted)]">
                  {svc.description}
                </p>
              </div>

              <div className="pt-4 border-t border-[var(--solo-border-subtle)] text-xs text-[var(--solo-text-muted)] flex flex-wrap items-center gap-x-2 gap-y-1">
                {svc.deliverables.map((d, dIdx) => (
                  <React.Fragment key={d}>
                    <span>{d}</span>
                    {dIdx < svc.deliverables.length - 1 && (
                      <span aria-hidden="true">·</span>
                    )}
                  </React.Fragment>
                ))}
              </div>
            </motion.article>
          ))}
        </div>
      </section>

      {/* Interactive Creative Process */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div
          className="rounded-2xl border p-6 sm:p-10 space-y-8 theme-transition"
          style={{
            backgroundColor: 'var(--solo-surface)',
            borderColor: 'var(--solo-border)',
          }}
        >
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div className="space-y-2">
              <p
                className="text-xs font-semibold tracking-[0.2em] uppercase flex items-center gap-2"
                style={{ color: theme.accentBright }}
              >
                <Compass className="w-3.5 h-3.5" />
                <span>Creative Process</span>
              </p>
              <h2 className="font-display text-2xl sm:text-3xl font-bold text-[var(--solo-text)]">
                From Concept to Living Interface.
              </h2>
            </div>
            <span className="text-xs text-[var(--solo-text-muted)]">
              Select any phase to inspect workflow
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
            <div className="lg:col-span-5 flex flex-col gap-2.5">
              {PROCESS_STEPS.map((item, idx) => {
                const active = activeStep === idx;
                return (
                  <button
                    key={item.step}
                    type="button"
                    onClick={() => {
                      playSfx('click');
                      setActiveStep(idx);
                    }}
                    className="w-full text-left px-4 py-3.5 min-h-[54px] rounded-xl border flex items-center justify-between gap-3 transition-all duration-200 focus-visible:outline-none focus-visible:ring-2"
                    style={{
                      backgroundColor: active
                        ? 'var(--solo-surface-elevated)'
                        : 'var(--solo-bg)',
                      borderColor: active
                        ? theme.accentBright
                        : 'var(--solo-border-subtle)',
                    }}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span
                        className="font-mono-tabular text-xs font-semibold shrink-0"
                        style={{
                          color: active
                            ? theme.accentBright
                            : 'var(--solo-text-muted)',
                        }}
                      >
                        {item.step}
                      </span>
                      <span className="font-display text-sm sm:text-base font-semibold text-[var(--solo-text)] truncate">
                        {item.title}
                      </span>
                    </div>
                    <ArrowRight
                      className="w-4 h-4 shrink-0 transition-transform duration-200"
                      style={{
                        color: active
                          ? theme.accentBright
                          : 'var(--solo-text-muted)',
                        transform: active ? 'translateX(2px)' : 'none',
                      }}
                    />
                  </button>
                );
              })}
            </div>

            <div
              className="lg:col-span-7 p-6 sm:p-8 rounded-2xl border flex flex-col justify-between gap-6"
              style={{
                backgroundColor: 'var(--solo-bg)',
                borderColor: 'var(--solo-border-subtle)',
              }}
            >
              <div className="space-y-4">
                <span
                  className="font-mono-tabular text-xs font-semibold"
                  style={{ color: theme.accentBright }}
                >
                  Phase {PROCESS_STEPS[activeStep].step}
                </span>
                <h3 className="font-display text-2xl font-bold text-[var(--solo-text)]">
                  {PROCESS_STEPS[activeStep].title}
                </h3>
                <p className="text-base leading-relaxed text-[var(--solo-text-muted)]">
                  {PROCESS_STEPS[activeStep].description}
                </p>
              </div>

              <div className="pt-4 border-t border-[var(--solo-border-subtle)] flex items-center justify-between gap-4 text-sm">
                <span className="text-[var(--solo-text-muted)]">Outcome</span>
                <span
                  className="font-medium text-right"
                  style={{ color: theme.accentBright }}
                >
                  {PROCESS_STEPS[activeStep].outcome}
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Experience & Journey + Technology Stack */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-12">
        <div className="space-y-3 max-w-2xl">
          <p
            className="text-xs font-semibold tracking-[0.2em] uppercase"
            style={{ color: theme.accentBright }}
          >
            Experience & Journey
          </p>
          <h2
            className="font-display font-bold tracking-tight text-[var(--solo-text)]"
            style={{ fontSize: 'clamp(1.85rem, 3.6vw, 2.75rem)' }}
          >
            Evolution of the Craft.
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {JOURNEY_MILESTONES.map((m, idx) => (
            <motion.div
              key={m.phase}
              initial={isReducedMotion ? false : { opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.45, delay: idx * 0.06 }}
              className="p-6 rounded-2xl border flex flex-col justify-between gap-4"
              style={{
                backgroundColor: 'var(--solo-surface)',
                borderColor: 'var(--solo-border-subtle)',
              }}
            >
              <div className="space-y-2.5">
                <span
                  className="font-mono-tabular text-xs font-semibold"
                  style={{ color: theme.accentBright }}
                >
                  {m.phase}
                </span>
                <h3 className="font-display text-lg font-semibold text-[var(--solo-text)]">
                  {m.title}
                </h3>
                <p className="text-xs font-medium text-[var(--solo-text-muted)]">
                  {m.focus}
                </p>
              </div>
              <p className="text-sm leading-relaxed text-[var(--solo-text-muted)]">
                {m.description}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Clean Technology Stack Strip */}
        <div
          className="p-6 rounded-2xl border flex flex-col md:flex-row md:items-center justify-between gap-4"
          style={{
            backgroundColor: 'var(--solo-surface)',
            borderColor: 'var(--solo-border-subtle)',
          }}
        >
          <span className="inline-flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-[var(--solo-text)] shrink-0">
            <Cpu className="w-4 h-4" style={{ color: theme.accentBright }} />
            <span>Core Stack</span>
          </span>
          <div className="text-sm text-[var(--solo-text-muted)] flex flex-wrap items-center gap-x-3 gap-y-1.5">
            {TECH_STACK.map((tech, idx) => (
              <React.Fragment key={tech}>
                <span className="text-[var(--solo-text)] font-medium">
                  {tech}
                </span>
                {idx < TECH_STACK.length - 1 && (
                  <span aria-hidden="true" className="text-[var(--solo-text-muted)]">
                    ·
                  </span>
                )}
              </React.Fragment>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};
