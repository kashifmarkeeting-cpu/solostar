import React from 'react';
import { useSolo } from '../context/SoloContext';

interface BrandMarkProps {
  size?: 'sm' | 'md' | 'lg';
  showWordmark?: boolean;
}

export const BrandMark: React.FC<BrandMarkProps> = ({
  size = 'md',
  showWordmark = true,
}) => {
  const { theme } = useSolo();
  const dims =
    size === 'sm' ? 'w-7 h-7' : size === 'lg' ? 'w-12 h-12' : 'w-8 h-8';

  return (
    <span className="inline-flex items-center gap-2.5 whitespace-nowrap shrink-0 select-none">
      <svg
        viewBox="0 0 48 48"
        fill="none"
        className={`${dims} theme-transition shrink-0`}
        aria-hidden="true"
      >
        <rect
          x="3"
          y="3"
          width="42"
          height="42"
          rx="11"
          fill="var(--solo-surface)"
          stroke="var(--solo-border)"
          strokeWidth="1.5"
        />
        <path
          d="M12 31L15.5 18.5L24 24.5L32.5 18.5L36 31H12Z"
          stroke={theme.accentBright}
          strokeWidth="2.1"
          strokeLinejoin="round"
        />
        <circle cx="15.5" cy="14.5" r="1.75" fill={theme.accentBright} />
        <circle cx="24" cy="12.5" r="2.1" fill={theme.text} />
        <circle cx="32.5" cy="14.5" r="1.75" fill={theme.accentBright} />
        <path
          d="M15 35.5H33"
          stroke={theme.accent}
          strokeWidth="2"
          strokeLinecap="round"
        />
      </svg>
      {showWordmark && (
        <span
          className="font-display font-bold tracking-[0.18em] text-base sm:text-lg"
          style={{ color: 'var(--solo-text)' }}
        >
          SOLO
        </span>
      )}
    </span>
  );
};
