import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Clock,
  Lock,
  Music,
  Palette,
  RefreshCw,
  Sliders,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { THEME_ORDER, THEMES } from '../config/themes';
import { useSolo } from '../context/SoloContext';
import { PWAInstallButton } from './PWAStatus';

interface StudioDrawerProps {
  open: boolean;
  onClose: () => void;
}

export const StudioDrawer: React.FC<StudioDrawerProps> = ({ open, onClose }) => {
  const {
    theme,
    themeId,
    autoRotate,
    rotationIntervalSec,
    secondsRemaining,
    setTheme,
    toggleAutoRotate,
    setRotationIntervalSec,
    soundPrefs,
    toggleMasterSound,
    toggleAmbient,
    toggleSfx,
    setAmbientVolume,
    setSfxVolume,
    playSfx,
  } = useSolo();

  const [localTime, setLocalTime] = useState<string>(() =>
    new Intl.DateTimeFormat(undefined, {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    }).format(new Date())
  );

  useEffect(() => {
    if (!open) return;
    const id = window.setInterval(() => {
      setLocalTime(
        new Intl.DateTimeFormat(undefined, {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        }).format(new Date())
      );
    }, 1000);
    return () => window.clearInterval(id);
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[80] flex justify-end">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => {
              playSfx('menuClose');
              onClose();
            }}
            className="absolute inset-0 bg-black/65 backdrop-blur-sm"
          />

          <motion.aside
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.32, ease: [0.16, 1, 0.3, 1] }}
            role="dialog"
            aria-modal="true"
            aria-label="Theme and Sound Studio Preferences"
            className="relative z-10 w-full max-w-md h-full overflow-y-auto border-l p-6 sm:p-7 flex flex-col gap-7"
            style={{
              backgroundColor: 'var(--solo-surface)',
              borderColor: 'var(--solo-border)',
            }}
          >
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-[var(--solo-border-subtle)]">
              <div className="flex items-center gap-2.5">
                <Sliders
                  className="w-4 h-4"
                  style={{ color: theme.accentBright }}
                />
                <h2 className="font-display text-lg font-semibold tracking-tight text-[var(--solo-text)]">
                  Atmosphere & Sound
                </h2>
              </div>
              <button
                type="button"
                onClick={() => {
                  playSfx('menuClose');
                  onClose();
                }}
                aria-label="Close studio panel"
                className="min-w-[40px] min-h-[40px] inline-flex items-center justify-center rounded-xl border border-[var(--solo-border-subtle)] text-[var(--solo-text-muted)] hover:text-[var(--solo-text)] transition-colors focus-visible:outline-none focus-visible:ring-2"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Theme Selection */}
            <section className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="inline-flex items-center gap-2 text-sm font-semibold text-[var(--solo-text)]">
                  <Palette
                    className="w-4 h-4"
                    style={{ color: theme.accentBright }}
                  />
                  Color Identity
                </span>
                <span className="text-xs font-mono-tabular text-[var(--solo-text-muted)]">
                  {theme.name}
                </span>
              </div>

              <div className="grid grid-cols-1 gap-2.5">
                {THEME_ORDER.map((id) => {
                  const t = THEMES[id];
                  const active = id === themeId;
                  return (
                    <button
                      key={id}
                      type="button"
                      onClick={() => setTheme(id, true)}
                      className="w-full text-left p-3.5 rounded-xl border transition-all duration-200 flex items-center justify-between gap-3 min-h-[56px] focus-visible:outline-none focus-visible:ring-2"
                      style={{
                        backgroundColor: active
                          ? 'var(--solo-surface-elevated)'
                          : 'var(--solo-bg)',
                        borderColor: active
                          ? t.accentBright
                          : 'var(--solo-border-subtle)',
                        boxShadow: active ? `0 0 20px -6px ${t.glow}` : 'none',
                      }}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <span
                          className="w-7 h-7 rounded-lg shrink-0 border border-white/15"
                          style={{ background: t.swatchGradient }}
                          aria-hidden="true"
                        />
                        <div className="min-w-0">
                          <div className="text-sm font-semibold text-[var(--solo-text)] truncate">
                            {t.name}
                          </div>
                          <div className="text-xs text-[var(--solo-text-muted)] truncate">
                            {t.subtitle}
                          </div>
                        </div>
                      </div>
                      <span className="text-xs font-medium shrink-0 whitespace-nowrap" style={{ color: active ? t.accentBright : 'var(--solo-text-muted)' }}>
                        {active ? 'Active' : 'Select'}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Auto-rotation vs Manual Lock */}
              <div
                className="p-4 rounded-xl border space-y-3.5"
                style={{
                  backgroundColor: 'var(--solo-bg)',
                  borderColor: 'var(--solo-border-subtle)',
                }}
              >
                <div className="flex items-center justify-between gap-3">
                  <div className="space-y-0.5">
                    <div className="text-sm font-medium text-[var(--solo-text)] flex items-center gap-2">
                      {autoRotate ? (
                        <RefreshCw
                          className="w-3.5 h-3.5"
                          style={{ color: theme.accentBright }}
                        />
                      ) : (
                        <Lock className="w-3.5 h-3.5 text-[var(--solo-text-muted)]" />
                      )}
                      <span>
                        {autoRotate ? 'Auto-Rotation Active' : 'Manual Theme Lock'}
                      </span>
                    </div>
                    <p className="text-xs text-[var(--solo-text-muted)]">
                      {autoRotate
                        ? `Next transition in ${secondsRemaining}s`
                        : 'Selected theme stays locked across visits'}
                    </p>
                  </div>

                  <button
                    type="button"
                    role="switch"
                    aria-checked={autoRotate}
                    onClick={toggleAutoRotate}
                    className="px-3.5 py-2 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-colors min-h-[38px] focus-visible:outline-none focus-visible:ring-2"
                    style={{
                      backgroundColor: autoRotate
                        ? theme.accent
                        : 'var(--solo-surface-elevated)',
                      color: autoRotate ? '#ffffff' : 'var(--solo-text)',
                      border: `1px solid ${
                        autoRotate ? theme.accentBright : 'var(--solo-border-subtle)'
                      }`,
                    }}
                  >
                    {autoRotate ? 'Lock Manual' : 'Auto Rotate'}
                  </button>
                </div>

                {autoRotate && (
                  <div className="space-y-1.5 pt-2 border-t border-[var(--solo-border-subtle)]">
                    <div className="flex items-center justify-between text-xs text-[var(--solo-text-muted)]">
                      <span>Rotation Cadence</span>
                      <span className="font-mono-tabular text-[var(--solo-text)]">
                        {rotationIntervalSec}s
                      </span>
                    </div>
                    <input
                      type="range"
                      min={30}
                      max={60}
                      step={5}
                      value={rotationIntervalSec}
                      onChange={(e) =>
                        setRotationIntervalSec(Number(e.target.value))
                      }
                      aria-label="Theme rotation interval in seconds"
                      className="w-full accent-[var(--solo-accent)] cursor-pointer"
                    />
                  </div>
                )}
              </div>
            </section>

            {/* Sound System Controls */}
            <section className="space-y-4 pt-2 border-t border-[var(--solo-border-subtle)]">
              <div className="flex items-center justify-between">
                <span className="inline-flex items-center gap-2 text-sm font-semibold text-[var(--solo-text)]">
                  {soundPrefs.masterEnabled ? (
                    <Volume2
                      className="w-4 h-4"
                      style={{ color: theme.accentBright }}
                    />
                  ) : (
                    <VolumeX className="w-4 h-4 text-[var(--solo-text-muted)]" />
                  )}
                  Audio Environment
                </span>

                <button
                  type="button"
                  role="switch"
                  aria-checked={soundPrefs.masterEnabled}
                  onClick={toggleMasterSound}
                  className="px-3.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-colors min-h-[36px] focus-visible:outline-none focus-visible:ring-2"
                  style={{
                    backgroundColor: soundPrefs.masterEnabled
                      ? theme.accent
                      : 'var(--solo-bg)',
                    color: soundPrefs.masterEnabled
                      ? '#ffffff'
                      : 'var(--solo-text-muted)',
                    border: `1px solid ${
                      soundPrefs.masterEnabled
                        ? theme.accentBright
                        : 'var(--solo-border-subtle)'
                    }`,
                  }}
                >
                  {soundPrefs.masterEnabled ? 'Sound On' : 'Sound Off'}
                </button>
              </div>

              <div
                className="p-4 rounded-xl border space-y-4"
                style={{
                  backgroundColor: 'var(--solo-bg)',
                  borderColor: 'var(--solo-border-subtle)',
                }}
              >
                {/* Ambient Music Channel */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-3">
                    <span className="inline-flex items-center gap-2 text-xs font-medium text-[var(--solo-text)]">
                      <Music className="w-3.5 h-3.5 text-[var(--solo-text-muted)]" />
                      Ambient Soundscape
                    </span>
                    <button
                      type="button"
                      onClick={toggleAmbient}
                      className="text-xs font-medium px-2.5 py-1 rounded-md border border-[var(--solo-border-subtle)] text-[var(--solo-text)] hover:border-[var(--solo-border)]"
                    >
                      {soundPrefs.ambientEnabled ? 'Active' : 'Muted'}
                    </button>
                  </div>
                  <div className="flex items-center gap-3">
                    <input
                      type="range"
                      min={0}
                      max={100}
                      value={Math.round(soundPrefs.ambientVolume * 100)}
                      onChange={(e) =>
                        setAmbientVolume(Number(e.target.value) / 100)
                      }
                      aria-label="Ambient music volume"
                      className="w-full accent-[var(--solo-accent)] cursor-pointer"
                    />
                    <span className="w-9 text-right text-xs font-mono-tabular text-[var(--solo-text-muted)]">
                      {Math.round(soundPrefs.ambientVolume * 100)}%
                    </span>
                  </div>
                </div>

                {/* Interface SFX Channel */}
                <div className="space-y-2 pt-3 border-t border-[var(--solo-border-subtle)]">
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-xs font-medium text-[var(--solo-text)]">
                      Interface Sound Effects
                    </span>
                    <button
                      type="button"
                      onClick={toggleSfx}
                      className="text-xs font-medium px-2.5 py-1 rounded-md border border-[var(--solo-border-subtle)] text-[var(--solo-text)] hover:border-[var(--solo-border)]"
                    >
                      {soundPrefs.sfxEnabled ? 'Active' : 'Muted'}
                    </button>
                  </div>
                  <div className="flex items-center gap-3">
                    <input
                      type="range"
                      min={0}
                      max={100}
                      value={Math.round(soundPrefs.sfxVolume * 100)}
                      onChange={(e) =>
                        setSfxVolume(Number(e.target.value) / 100)
                      }
                      aria-label="Interface sound effects volume"
                      className="w-full accent-[var(--solo-accent)] cursor-pointer"
                    />
                    <span className="w-9 text-right text-xs font-mono-tabular text-[var(--solo-text-muted)]">
                      {Math.round(soundPrefs.sfxVolume * 100)}%
                    </span>
                  </div>
                </div>
              </div>
            </section>

            {/* Footer Metadata + PWA Install */}
            <div className="mt-auto pt-4 border-t border-[var(--solo-border-subtle)] space-y-4">
              <PWAInstallButton />
              <div className="flex items-center justify-between text-xs text-[var(--solo-text-muted)]">
                <span className="inline-flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5" />
                  Local Time
                </span>
                <span className="font-mono-tabular text-[var(--solo-text)]">
                  {localTime}
                </span>
              </div>
            </div>
          </motion.aside>
        </div>
      )}
    </AnimatePresence>
  );
};
