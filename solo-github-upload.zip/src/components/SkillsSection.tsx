import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Code2,
  Cpu,
  Layout,
  Palette,
  Sparkles,
  Wand2,
} from 'lucide-react';
import { useSolo } from '../context/SoloContext';
import { SKILL_GROUPS } from '../data/portfolioContent';

const CATEGORY_ICONS: Record<string, React.ReactNode> = {
  frontend: <Code2 className="w-4 h-4 shrink-0" />,
  'web-design': <Layout className="w-4 h-4 shrink-0" />,
  'ui-ux': <Palette className="w-4 h-4 shrink-0" />,
  'creative-dev': <Wand2 className="w-4 h-4 shrink-0" />,
  interactive: <Cpu className="w-4 h-4 shrink-0" />,
  'digital-creativity': <Sparkles className="w-4 h-4 shrink-0" />,
};

export const SkillsSection: React.FC = () => {
  const { theme, isReducedMotion, playSfx } = useSolo();
  const [selectedId, setSelectedId] = useState(SKILL_GROUPS[0].id);

  const activeGroup =
    SKILL_GROUPS.find((g) => g.id === selectedId) ?? SKILL_GROUPS[0];

  const tierBarWidth = (tier: string) => {
    if (tier === 'Core Craft') return '88%';
    if (tier === 'Specialized') return '74%';
    return '58%';
  };

  return (
    <section
      id="skills"
      className="relative py-20 sm:py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto"
    >
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-12">
        <div className="space-y-3 max-w-2xl">
          <p
            className="text-xs font-semibold tracking-[0.2em] uppercase"
            style={{ color: theme.accentBright }}
          >
            Capabilities & Disciplines
          </p>
          <h2
            className="font-display font-bold tracking-tight text-[var(--solo-text)]"
            style={{ fontSize: 'clamp(2rem, 4vw, 3rem)' }}
          >
            Craft Across Code & Motion.
          </h2>
        </div>

        <p className="text-sm sm:text-base text-[var(--solo-text-muted)] max-w-md">
          Organized by creative and engineering discipline rather than arbitrary
          percentages—focused on real capability and clarity.
        </p>
      </div>

      {/* Category Selector Tabs */}
      <div
        className="flex flex-wrap gap-2 mb-10"
        role="tablist"
        aria-label="Skill categories"
      >
        {SKILL_GROUPS.map((group) => {
          const active = group.id === activeGroup.id;
          return (
            <button
              key={group.id}
              type="button"
              role="tab"
              aria-selected={active}
              onClick={() => {
                playSfx('click');
                setSelectedId(group.id);
              }}
              className="inline-flex items-center gap-2 px-4 py-2.5 min-h-[42px] rounded-xl text-xs sm:text-sm font-medium whitespace-nowrap shrink-0 border transition-all duration-200 focus-visible:outline-none focus-visible:ring-2"
              style={{
                backgroundColor: active
                  ? theme.accentMuted
                  : 'var(--solo-surface)',
                borderColor: active
                  ? theme.accentBright
                  : 'var(--solo-border-subtle)',
                color: active ? 'var(--solo-text)' : 'var(--solo-text-muted)',
              }}
            >
              <span style={{ color: active ? theme.accentBright : 'inherit' }}>
                {CATEGORY_ICONS[group.id]}
              </span>
              <span>{group.label}</span>
            </button>
          );
        })}
      </div>

      {/* Active Category Header + Cards */}
      <div className="space-y-8">
        <div
          className="p-6 sm:p-7 rounded-2xl border flex flex-col md:flex-row md:items-center justify-between gap-4 theme-transition"
          style={{
            backgroundColor: 'var(--solo-surface)',
            borderColor: 'var(--solo-border)',
          }}
        >
          <div className="space-y-1.5">
            <h3 className="font-display text-xl sm:text-2xl font-semibold text-[var(--solo-text)]">
              {activeGroup.headline}
            </h3>
            <p className="text-sm sm:text-base text-[var(--solo-text-muted)] max-w-2xl">
              {activeGroup.description}
            </p>
          </div>
          <span
            className="text-xs font-medium tracking-wider uppercase whitespace-nowrap shrink-0"
            style={{ color: theme.accentBright }}
          >
            {activeGroup.label}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {activeGroup.capabilities.map((cap, idx) => (
            <motion.article
              key={`${activeGroup.id}-${cap.name}`}
              initial={isReducedMotion ? false : { opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                duration: 0.35,
                delay: idx * 0.06,
                ease: [0.16, 1, 0.3, 1],
              }}
              className="group p-6 rounded-2xl border flex flex-col justify-between gap-5 transition-all duration-300 hover:-translate-y-1 theme-transition"
              style={{
                backgroundColor: 'var(--solo-surface)',
                borderColor: 'var(--solo-border-subtle)',
              }}
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-3">
                  <span
                    className="text-xs font-medium tracking-wide"
                    style={{ color: theme.accentBright }}
                  >
                    {cap.tier}
                  </span>
                  <span className="text-xs font-mono-tabular text-[var(--solo-text-muted)]">
                    0{idx + 1}
                  </span>
                </div>

                <h4 className="font-display text-lg font-semibold text-[var(--solo-text)]">
                  {cap.name}
                </h4>

                <p className="text-sm leading-relaxed text-[var(--solo-text-muted)]">
                  {cap.detail}
                </p>
              </div>

              <div className="space-y-4">
                {/* Glowing Qualitative Craft Indicator */}
                <div
                  className="h-1 w-full rounded-full overflow-hidden"
                  style={{ backgroundColor: 'var(--solo-bg)' }}
                >
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: tierBarWidth(cap.tier),
                      backgroundColor: theme.accentBright,
                      boxShadow: `0 0 12px ${theme.glow}`,
                    }}
                  />
                </div>

                {/* Clean Unboxed Tool List */}
                <div className="text-xs text-[var(--solo-text-muted)] flex flex-wrap items-center gap-x-2 gap-y-1">
                  {cap.tools.map((tool, tIdx) => (
                    <React.Fragment key={tool}>
                      <span>{tool}</span>
                      {tIdx < cap.tools.length - 1 && (
                        <span aria-hidden="true">·</span>
                      )}
                    </React.Fragment>
                  ))}
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
};
