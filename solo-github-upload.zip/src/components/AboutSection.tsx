import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Layers, Sparkles, Terminal } from 'lucide-react';
import { useSolo } from '../context/SoloContext';
import { ABOUT_CONTENT, PORTRAIT_SRC } from '../data/portfolioContent';

export const AboutSection: React.FC = () => {
  const { theme, isReducedMotion, playSfx } = useSolo();
  const [activePillar, setActivePillar] = useState(0);
  const [imgError, setImgError] = useState(false);

  const pillarIcons = [
    <Terminal key="dev" className="w-4 h-4" />,
    <Sparkles key="phi" className="w-4 h-4" />,
    <Layers key="int" className="w-4 h-4" />,
  ];

  return (
    <section
      id="about"
      className="relative py-20 sm:py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto"
    >
      {/* Subtle Editorial Marquee Divider */}
      <div
        className="mb-16 overflow-hidden border-y py-3 select-none"
        style={{ borderColor: 'var(--solo-border-subtle)' }}
        aria-hidden="true"
      >
        <div className="flex w-max animate-marquee text-xs tracking-[0.25em] uppercase text-[var(--solo-text-muted)]">
          <span className="px-6">
            Digital Identity · Creative Development · Motion Architecture · UI Craft ·
          </span>
          <span className="px-6">
            Digital Identity · Creative Development · Motion Architecture · UI Craft ·
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-stretch">
        {/* Left: Framed Portrait Detail */}
        <motion.div
          initial={isReducedMotion ? false : { opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.25 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="lg:col-span-5 flex"
        >
          <div
            className="relative w-full rounded-2xl border overflow-hidden flex flex-col justify-end p-6 min-h-[380px] sm:min-h-[460px] theme-transition"
            style={{
              backgroundColor: 'var(--solo-surface)',
              borderColor: 'var(--solo-border)',
            }}
          >
            {/* Atmospheric Spotlight */}
            <div
              className="absolute inset-0 pointer-events-none opacity-65 theme-transition"
              style={{
                background: `radial-gradient(circle at 50% 35%, ${theme.accentMuted}, transparent 68%)`,
              }}
              aria-hidden="true"
            />

            {!imgError ? (
              <img
                src={PORTRAIT_SRC}
                alt="SOLO creative studio portrait"
                loading="lazy"
                referrerPolicy="no-referrer"
                onError={() => setImgError(true)}
                className="relative z-10 w-full max-h-[400px] object-contain mx-auto theme-transition"
                style={{
                  filter: `drop-shadow(0 0 14px ${theme.glow})`,
                }}
              />
            ) : (
              <div className="relative z-10 py-20 text-center text-sm text-[var(--solo-text-muted)]">
                SOLO · Creative Studio
              </div>
            )}

            <div className="relative z-20 mt-4 pt-4 border-t border-[var(--solo-border-subtle)] flex items-center justify-between text-xs text-[var(--solo-text-muted)]">
              <span>Digital Creator · Developer</span>
              <span style={{ color: theme.accentBright }}>Identity 01</span>
            </div>
          </div>
        </motion.div>

        {/* Right: Editorial Narrative & Interactive Pillars */}
        <motion.div
          initial={isReducedMotion ? false : { opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.25 }}
          transition={{ duration: 0.6, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
          className="lg:col-span-7 flex flex-col justify-center space-y-6"
        >
          <div className="space-y-3">
            <p
              className="text-xs font-semibold tracking-[0.2em] uppercase"
              style={{ color: theme.accentBright }}
            >
              About SOLO
            </p>
            <h2
              className="font-display font-bold tracking-tight text-[var(--solo-text)]"
              style={{ fontSize: 'clamp(2rem, 4vw, 3.25rem)' }}
            >
              {ABOUT_CONTENT.headline}
            </h2>
          </div>

          <p className="text-lg sm:text-xl font-medium leading-relaxed text-[var(--solo-text)]">
            {ABOUT_CONTENT.lead}
          </p>

          <div className="space-y-4 text-base leading-relaxed text-[var(--solo-text-muted)] max-w-2xl">
            {ABOUT_CONTENT.paragraphs.map((p, idx) => (
              <p key={idx}>{p}</p>
            ))}
          </div>

          {/* Interactive Focus Cards */}
          <div className="pt-4 grid grid-cols-1 sm:grid-cols-3 gap-4">
            {ABOUT_CONTENT.pillars.map((pillar, idx) => {
              const isSelected = activePillar === idx;
              return (
                <button
                  key={pillar.title}
                  type="button"
                  onClick={() => {
                    playSfx('click');
                    setActivePillar(idx);
                  }}
                  className="text-left p-5 rounded-2xl border transition-all duration-200 flex flex-col gap-3 focus-visible:outline-none focus-visible:ring-2"
                  style={{
                    backgroundColor: isSelected
                      ? 'var(--solo-surface-elevated)'
                      : 'var(--solo-surface)',
                    borderColor: isSelected
                      ? theme.accentBright
                      : 'var(--solo-border-subtle)',
                    boxShadow: isSelected
                      ? `0 12px 30px -12px ${theme.glow}`
                      : 'none',
                  }}
                >
                  <div
                    className="w-9 h-9 rounded-xl flex items-center justify-center border"
                    style={{
                      backgroundColor: theme.accentMuted,
                      borderColor: theme.border,
                      color: theme.accentBright,
                    }}
                  >
                    {pillarIcons[idx]}
                  </div>
                  <h3 className="font-display text-base font-semibold text-[var(--solo-text)]">
                    {pillar.title}
                  </h3>
                  <p className="text-xs leading-relaxed text-[var(--solo-text-muted)]">
                    {pillar.detail}
                  </p>
                </button>
              );
            })}
          </div>
        </motion.div>
      </div>
    </section>
  );
};
