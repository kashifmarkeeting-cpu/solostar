import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, Palette, Volume2, VolumeX, X } from 'lucide-react';
import { useSolo } from '../context/SoloContext';
import { BrandMark } from './BrandMark';
import { PWAInstallButton } from './PWAStatus';
import { StudioDrawer } from './StudioDrawer';

const NAV_LINKS = [
  { id: 'home', label: 'Home' },
  { id: 'about', label: 'About' },
  { id: 'projects', label: 'Projects' },
  { id: 'skills', label: 'Skills' },
  { id: 'contact', label: 'Contact' },
];

export const Navbar: React.FC = () => {
  const {
    theme,
    soundPrefs,
    toggleMasterSound,
    playSfx,
    activeSection,
  } = useSolo();

  const [scrolled, setScrolled] = useState(false);
  const [studioOpen, setStudioOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleNavClick = (id: string) => {
    playSfx('nav');
    setMobileOpen(false);
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <header
        className="fixed top-0 inset-x-0 z-50 h-16 transition-[background-color,border-color,backdrop-filter] duration-300"
        style={{
          backgroundColor: scrolled
            ? 'color-mix(in srgb, var(--solo-bg) 82%, transparent)'
            : 'transparent',
          backdropFilter: scrolled ? 'blur(16px)' : 'none',
          borderBottom: scrolled
            ? '1px solid var(--solo-border-subtle)'
            : '1px solid transparent',
        }}
      >
        <div className="max-w-7xl mx-auto h-full px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-8">
          {/* Zone 1: Single-line Brand Wordmark */}
          <a
            href="#home"
            onClick={(e) => {
              e.preventDefault();
              handleNavClick('home');
            }}
            className="focus-visible:outline-none focus-visible:ring-2 rounded-lg"
            aria-label="SOLO Home"
          >
            <BrandMark size="sm" />
          </a>

          {/* Zone 2: 5 Clean Single-Line Nav Links */}
          <nav
            aria-label="Primary Navigation"
            className="hidden md:flex items-center gap-7"
          >
            {NAV_LINKS.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <a
                  key={item.id}
                  href={`#${item.id}`}
                  onClick={(e) => {
                    e.preventDefault();
                    handleNavClick(item.id);
                  }}
                  className="relative py-1 text-sm font-medium whitespace-nowrap shrink-0 transition-colors duration-200 focus-visible:outline-none focus-visible:ring-2 rounded"
                  style={{
                    color: isActive
                      ? 'var(--solo-text)'
                      : 'var(--solo-text-muted)',
                  }}
                >
                  {item.label}
                  <span
                    className="absolute inset-x-0 -bottom-0.5 h-0.5 rounded-full transition-transform duration-300 origin-left"
                    style={{
                      backgroundColor: theme.accentBright,
                      transform: isActive ? 'scaleX(1)' : 'scaleX(0)',
                    }}
                  />
                </a>
              );
            })}
          </nav>

          {/* Zone 3: Compact Theme & Sound Controls + Mobile Drawer Trigger */}
          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={toggleMasterSound}
              aria-label={
                soundPrefs.masterEnabled
                  ? 'Mute website sound'
                  : 'Enable ambient sound and interface effects'
              }
              title={
                soundPrefs.masterEnabled
                  ? 'Sound On (Click to mute)'
                  : 'Sound Off (Click to enable)'
              }
              className="min-w-[40px] min-h-[40px] px-2.5 inline-flex items-center justify-center gap-1.5 rounded-xl border text-xs font-medium whitespace-nowrap shrink-0 transition-colors focus-visible:outline-none focus-visible:ring-2"
              style={{
                backgroundColor: soundPrefs.masterEnabled
                  ? theme.accentMuted
                  : 'var(--solo-surface)',
                borderColor: soundPrefs.masterEnabled
                  ? theme.border
                  : 'var(--solo-border-subtle)',
                color: soundPrefs.masterEnabled
                  ? theme.accentBright
                  : 'var(--solo-text-muted)',
              }}
            >
              {soundPrefs.masterEnabled ? (
                <Volume2 className="w-4 h-4 shrink-0" />
              ) : (
                <VolumeX className="w-4 h-4 shrink-0" />
              )}
              <span className="hidden lg:inline">
                {soundPrefs.masterEnabled ? 'Sound On' : 'Sound'}
              </span>
            </button>

            <button
              type="button"
              onClick={() => {
                playSfx('menuOpen');
                setStudioOpen(true);
              }}
              aria-label="Open Theme and Sound Studio Controls"
              className="min-h-[40px] px-3.5 inline-flex items-center justify-center gap-2 rounded-xl border text-xs font-semibold whitespace-nowrap shrink-0 transition-colors focus-visible:outline-none focus-visible:ring-2"
              style={{
                backgroundColor: 'var(--solo-surface)',
                borderColor: 'var(--solo-border)',
                color: 'var(--solo-text)',
              }}
            >
              <span
                className="w-2.5 h-2.5 rounded-full shrink-0"
                style={{ background: theme.swatchGradient }}
                aria-hidden="true"
              />
              <Palette className="w-3.5 h-3.5 hidden sm:inline shrink-0" style={{ color: theme.accentBright }} />
              <span>Theme</span>
            </button>

            <button
              type="button"
              onClick={() => {
                playSfx(mobileOpen ? 'menuClose' : 'menuOpen');
                setMobileOpen((v) => !v);
              }}
              aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
              aria-expanded={mobileOpen}
              className="md:hidden min-w-[42px] min-h-[42px] inline-flex items-center justify-center rounded-xl border text-[var(--solo-text)] focus-visible:outline-none focus-visible:ring-2"
              style={{
                backgroundColor: 'var(--solo-surface)',
                borderColor: 'var(--solo-border-subtle)',
              }}
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Navigation Drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <div className="fixed inset-0 z-[75] md:hidden">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                playSfx('menuClose');
                setMobileOpen(false);
              }}
              className="absolute inset-0 bg-black/70 backdrop-blur-sm"
            />
            <motion.nav
              initial={{ y: -24, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -24, opacity: 0 }}
              transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
              aria-label="Mobile Navigation"
              className="relative z-10 mx-4 mt-20 rounded-2xl border p-5 space-y-2 shadow-2xl"
              style={{
                backgroundColor: 'var(--solo-surface)',
                borderColor: 'var(--solo-border)',
              }}
            >
              {NAV_LINKS.map((item) => {
                const isActive = activeSection === item.id;
                return (
                  <a
                    key={item.id}
                    href={`#${item.id}`}
                    onClick={(e) => {
                      e.preventDefault();
                      handleNavClick(item.id);
                    }}
                    className="flex items-center justify-between px-4 py-3.5 min-h-[46px] rounded-xl text-base font-medium transition-colors"
                    style={{
                      backgroundColor: isActive
                        ? theme.accentMuted
                        : 'transparent',
                      color: isActive
                        ? theme.accentBright
                        : 'var(--solo-text)',
                    }}
                  >
                    <span>{item.label}</span>
                    <span className="text-xs text-[var(--solo-text-muted)]">
                      {isActive ? 'Current' : 'View'}
                    </span>
                  </a>
                );
              })}

              <div className="pt-3 mt-2 border-t border-[var(--solo-border-subtle)] flex flex-col gap-2.5">
                <button
                  type="button"
                  onClick={() => {
                    setMobileOpen(false);
                    setStudioOpen(true);
                  }}
                  className="w-full min-h-[44px] px-4 py-2.5 rounded-xl text-sm font-semibold border text-[var(--solo-text)] flex items-center justify-center gap-2"
                  style={{
                    backgroundColor: 'var(--solo-bg)',
                    borderColor: 'var(--solo-border)',
                  }}
                >
                  <Palette
                    className="w-4 h-4"
                    style={{ color: theme.accentBright }}
                  />
                  <span>Customize Theme & Sound</span>
                </button>
                <PWAInstallButton />
              </div>
            </motion.nav>
          </div>
        )}
      </AnimatePresence>

      <StudioDrawer open={studioOpen} onClose={() => setStudioOpen(false)} />
    </>
  );
};
