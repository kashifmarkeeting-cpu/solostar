import type {
  JourneyMilestone,
  ProcessStep,
  ProjectItem,
  ServiceItem,
  SkillGroup,
} from '../types/solo';

export const PORTRAIT_SRC =
  '/assets/aistudio/Stylish_Young_Man_with_Earphones_3409ba2a.png';

export const HERO_COPY = {
  intro: 'Hello, welcome to my digital world',
  greeting: "Hello, I'm",
  brand: 'SOLO',
  roles: [
    'Developer',
    'Digital Creator',
    'Designer',
    'Creative Mind',
    'Technology Enthusiast',
  ],
  description:
    'Exploring the digital world, building creative experiences, and turning ambitious ideas into reality.',
  primaryCta: 'Explore My World',
  secondaryCta: "Let's Connect",
};

export const ABOUT_CONTENT = {
  headline: 'Beyond the Ordinary.',
  lead: 'I craft interactive digital spaces where engineering precision meets atmospheric design.',
  paragraphs: [
    "Under the identity SOLO, I explore how modern web architecture, expressive typography, and responsive motion come together to shape memorable digital products.",
    'Every interface is treated as a living environment—balancing crisp usability and performance with intentional lighting, sound, and tactile micro-interactions.',
  ],
  pillars: [
    {
      title: 'Developer Identity',
      detail:
        'Focused on clean TypeScript architecture, modular React systems, and fluid GPU-friendly animation pipelines.',
    },
    {
      title: 'Creative Philosophy',
      detail:
        'Technology feels most human when every transition has purpose, rhythm, and clarity—never visual noise.',
    },
    {
      title: 'Digital Interests',
      detail:
        'Generative WebGL visuals, spatial audio interfaces, adaptive design systems, and cross-platform mobile experiences.',
    },
  ],
};

export const SKILL_GROUPS: SkillGroup[] = [
  {
    id: 'frontend',
    label: 'Frontend Development',
    headline: 'Resilient Architecture & Motion Code',
    description:
      'Building fast, accessible, component-driven web applications engineered to scale cleanly across desktop and mobile.',
    capabilities: [
      {
        name: 'React & TypeScript Systems',
        tier: 'Core Craft',
        detail:
          'Typed state architecture, custom hooks, and modular reusable UI primitives built for longevity.',
        tools: ['React 19', 'TypeScript', 'Vite', 'State Contexts'],
      },
      {
        name: 'Responsive Adaptive Layouts',
        tier: 'Core Craft',
        detail:
          'Mobile-first CSS Grid and Flexbox compositions with fluid clamp() typography and zero horizontal overflow.',
        tools: ['Tailwind CSS', 'CSS Grid', 'Fluid Type', 'PWA Ready'],
      },
      {
        name: 'Performance & Accessibility',
        tier: 'Specialized',
        detail:
          'GPU-composited animations, reduced-motion compliance, lazy media loading, and semantic keyboard navigation.',
        tools: ['A11y / WCAG', 'Code Splitting', 'Device Adaptation'],
      },
    ],
  },
  {
    id: 'web-design',
    label: 'Web Design',
    headline: 'Editorial Hierarchy & Visual Direction',
    description:
      'Designing cohesive digital surfaces where contrast, negative space, and typographic pacing guide attention effortlessly.',
    capabilities: [
      {
        name: 'Dynamic Theme Systems',
        tier: 'Core Craft',
        detail:
          'Multi-palette CSS token architectures that transition atmosphere seamlessly without altering structural integrity.',
        tools: ['Design Tokens', 'Color Contrast', 'Surface Depth'],
      },
      {
        name: 'Kinetic Typography',
        tier: 'Specialized',
        detail:
          'Expressive display scales, staggered text reveals, and controlled transition choreography.',
        tools: ['Outfit Display', 'Type Scales', 'Text Choreography'],
      },
      {
        name: 'Visual Composition',
        tier: 'Core Craft',
        detail:
          'Balancing focal anchors, asymmetric grids, and layered media framing across every viewport.',
        tools: ['Bento Grids', 'Editorial Splits', 'Lighting Rim'],
      },
    ],
  },
  {
    id: 'ui-ux',
    label: 'UI/UX Design',
    headline: 'Intuitive Flows & Tactile Feedback',
    description:
      'Translating complex capabilities into calm, human-centered controls that respond within milliseconds.',
    capabilities: [
      {
        name: 'Interaction Design',
        tier: 'Core Craft',
        detail:
          'Sub-200ms hover settling, magnetic affordances, and clear feedback across desktop cursors and touch screens.',
        tools: ['Micro-interactions', 'Touch Targets', 'Focus States'],
      },
      {
        name: 'Design Systems',
        tier: 'Specialized',
        detail:
          'Unified spacing, radius scales, and reusable component contracts tailored for web and future mobile apps.',
        tools: ['Component Tokens', 'Navigation Patterns', 'Modals'],
      },
      {
        name: 'Usability & Clarity',
        tier: 'Core Craft',
        detail:
          'Clear visual hierarchy, validated forms, and graceful offline or error states that never leave users guessing.',
        tools: ['Form Validation', 'Offline UX', 'Information Flow'],
      },
    ],
  },
  {
    id: 'creative-dev',
    label: 'Creative Development',
    headline: 'Atmospheric Motion & Procedural Audio',
    description:
      'Bridging visual art and engineering with real-time canvas environments and gentle procedural soundscapes.',
    capabilities: [
      {
        name: 'Interactive Canvas Worlds',
        tier: 'Specialized',
        detail:
          'Lightweight HTML5 Canvas particle fields, grids, and atmospheric lighting tuned to frame budgets.',
        tools: ['HTML5 Canvas', 'Parallax Layers', 'Particle Physics'],
      },
      {
        name: 'Motion Choreography',
        tier: 'Core Craft',
        detail:
          'Scroll-triggered reveals, spring physics, and smooth layout transitions powered by Motion.',
        tools: ['Motion', 'Scroll Triggers', 'Spring Curves'],
      },
      {
        name: 'Web Audio Synthesis',
        tier: 'Exploratory',
        detail:
          'Zero-dependency procedural ambient pads and subtle interface audio cues with independent user controls.',
        tools: ['Web Audio API', 'Ambient Pads', 'UI Sound Design'],
      },
    ],
  },
  {
    id: 'interactive',
    label: 'Interactive Experiences',
    headline: 'Immersive Storytelling on the Web',
    description:
      'Crafting portfolio experiences, launch pages, and digital exhibitions that invite active exploration.',
    capabilities: [
      {
        name: 'Cursor & Pointer Reactivity',
        tier: 'Specialized',
        detail:
          'Subtle magnetic buttons, spotlight surfaces, and parallax depth tuned specifically for desktop pointers.',
        tools: ['Pointer Tracking', 'Magnetic Pull', 'Depth Layers'],
      },
      {
        name: 'Installable PWA Architecture',
        tier: 'Specialized',
        detail:
          'Offline-ready service workers, standalone mobile shell behavior, and Capacitor-compatible state.',
        tools: ['Service Workers', 'Web Manifest', 'Capacitor Ready'],
      },
      {
        name: 'Modular Storytelling',
        tier: 'Core Craft',
        detail:
          'Cohesive multi-section pacing with smooth navigation, progress indicators, and deep-dive project drawers.',
        tools: ['Lightbox Modals', 'Scroll Spy', 'Section Rhythm'],
      },
    ],
  },
  {
    id: 'digital-creativity',
    label: 'Digital Creativity',
    headline: 'Concept Direction & Future Exploration',
    description:
      'Exploring emerging creative workflows from spatial interfaces to brand identity systems.',
    capabilities: [
      {
        name: 'Brand Identity & Art Direction',
        tier: 'Core Craft',
        detail:
          'Distinctive wordmarks, symbolic geometry, and cohesive atmosphere across visuals and copy.',
        tools: ['Identity Marks', 'Mood Systems', 'Visual Tone'],
      },
      {
        name: 'Rapid Interactive Prototyping',
        tier: 'Core Craft',
        detail:
          'Turning rough sparks into testable, animated browser prototypes quickly to validate feel and flow.',
        tools: ['Interactive Demos', 'Rapid Iteration', 'UI Labs'],
      },
      {
        name: 'Cross-Platform Thinking',
        tier: 'Exploratory',
        detail:
          'Designing shared logic and responsive interfaces ready to evolve from web experiences into native apps.',
        tools: ['Shared Logic', 'Mobile UX', 'App Shell'],
      },
    ],
  },
];

export const PROJECTS: ProjectItem[] = [
  {
    id: 'aurora-spatial',
    title: 'Aurora Spatial Synthesizer',
    category: 'Interactive',
    year: '2026',
    summary:
      'Interactive browser-based ambient sound workstation combining real-time waveform geometry with tactile hardware-inspired dials.',
    description:
      'A concept exploration in tactile web audio design. Built to prove that browser-native synthesis can feel physical, calm, and visually atmospheric without heavy plugin downloads.',
    image: '/src/assets/images/project_aurora_spatial_1795684134880.jpg',
    aspectRatio: '16:9',
    technologies: ['TypeScript', 'Web Audio API', 'Canvas 2D', 'Motion'],
    architectureNotes: [
      'Zero-dependency procedural polyphonic pad engine with soft resonant filtering.',
      '60fps oscilloscope canvas decoupled from React state updates via refs.',
      'Touch-friendly rotary dial physics supporting vertical drag and keyboard nudges.',
    ],
    deliverables: [
      'Interactive Audio Prototype',
      'Waveform Visualizer Engine',
      'Custom Hardware-Inspired UI Kit',
    ],
    conceptStatus: 'Showcase Concept · Placeholder Portfolio Entry',
  },
  {
    id: 'kinetic-monolith',
    title: 'Monolith Kinetic Exhibition',
    category: 'Design Systems',
    year: '2026',
    summary:
      'Editorial exhibition site pairing architectural monochrome photography with sculptural typographic pacing and fluid transitions.',
    description:
      'An editorial digital gallery experiment focused on negative space, measured contrast scrims, and seamless transition choreography between curated spatial works.',
    image: '/src/assets/images/project_kinetic_type_1795684135528.jpg',
    aspectRatio: '4:3',
    technologies: ['React', 'Tailwind CSS', 'Motion', 'Fluid Type'],
    architectureNotes: [
      'Dynamic clamp() typographic scale calibrated across 360px to 1920px viewports.',
      'GPU-composited image reveals avoiding layout shift or paint thrashing.',
      'Keyboard-accessible lightbox viewer with instant ESC and arrow navigation.',
    ],
    deliverables: [
      'Editorial Layout System',
      'Kinetic Type Primitives',
      'Responsive Gallery Lightbox',
    ],
    conceptStatus: 'Showcase Concept · Placeholder Portfolio Entry',
  },
  {
    id: 'nebula-prism',
    title: 'Prism Light Field Lab',
    category: 'Spatial & WebGL',
    year: '2025',
    summary:
      'Atmospheric particle and light-refraction study translating pointer movement into layered rim lighting and volumetric depth.',
    description:
      'A visual laboratory studying how minimal dark surfaces come alive with subtle directional lighting, particle drift, and adaptive performance scaling for mobile devices.',
    image: '/src/assets/images/project_nebula_engine_1795684135486.jpg',
    aspectRatio: '4:3',
    technologies: ['HTML5 Canvas', 'TypeScript', 'CSS Tokens', 'A11y'],
    architectureNotes: [
      'Automatic frame-budget adaptation scaling particle count on low-power devices.',
      'Full prefers-reduced-motion fallback rendering static atmospheric gradients.',
      'Synchronized color token architecture supporting instant palette transitions.',
    ],
    deliverables: [
      'Adaptive Particle Engine',
      'Multi-Theme Token Pipeline',
      'Pointer Parallax System',
    ],
    conceptStatus: 'Showcase Concept · Placeholder Portfolio Entry',
  },
  {
    id: 'solo-mobile-os',
    title: 'Continuum Cross-Device Shell',
    category: 'Design Systems',
    year: '2026',
    summary:
      'Unified progressive web and mobile application shell designed for seamless handoff between desktop workspaces and pocket screens.',
    description:
      'An architectural blueprint for converting rich interactive web experiences into installable PWAs and Capacitor-ready mobile applications with shared state.',
    image: '/src/assets/images/project_monolith_os_1795684135893.jpg',
    aspectRatio: '16:9',
    technologies: ['React', 'PWA', 'Service Workers', 'Capacitor Architecture'],
    architectureNotes: [
      'Platform-agnostic storage and audio interfaces ready for native mobile bridges.',
      'Offline-first asset caching strategy with transparent connectivity awareness.',
      'Thumb-reachable mobile navigation drawer respecting safe-area insets.',
    ],
    deliverables: [
      'PWA Manifest & Offline Cache',
      'Responsive Navigation Shell',
      'Shared Preference Store',
    ],
    conceptStatus: 'Showcase Concept · Placeholder Portfolio Entry',
  },
];

export const SERVICES: ServiceItem[] = [
  {
    index: '01',
    title: 'Interactive Web Development',
    description:
      'Custom React and TypeScript applications engineered for responsiveness, clean architecture, and fluid motion.',
    deliverables: ['SPA & PWA Builds', 'Component Architecture', 'Performance Tuning'],
  },
  {
    index: '02',
    title: 'Creative UI & Motion Design',
    description:
      'Atmospheric interfaces with purposeful typography, refined dark-mode contrast, and tactile micro-interactions.',
    deliverables: ['Visual Direction', 'Motion Systems', 'Interactive Prototypes'],
  },
  {
    index: '03',
    title: 'Multi-Theme & Design Systems',
    description:
      'Token-driven design systems built to stay consistent across themes, viewports, and future mobile targets.',
    deliverables: ['Design Tokens', 'Reusable UI Kits', 'Accessibility Audits'],
  },
  {
    index: '04',
    title: 'Mobile-Ready Web Experiences',
    description:
      'Installable Progressive Web Apps structured cleanly for seamless transition into native iOS and Android shells.',
    deliverables: ['Offline Support', 'Touch Navigation', 'Capacitor Readiness'],
  },
];

export const PROCESS_STEPS: ProcessStep[] = [
  {
    step: '01',
    title: 'Immersion & Direction',
    description:
      'Defining the core identity, audience context, visual tone, and interactive goals before writing a single line of layout code.',
    outcome: 'Clear creative brief and visual direction',
  },
  {
    step: '02',
    title: 'System & Motion Architecture',
    description:
      'Establishing typography scales, multi-theme tokens, responsive grids, and meaningful animation rhythms.',
    outcome: 'Cohesive design system and interactive flow',
  },
  {
    step: '03',
    title: 'Precision Engineering',
    description:
      'Building modular TypeScript components, canvas/audio integrations, and accessible interactions with strict performance discipline.',
    outcome: 'Production-grade, responsive codebase',
  },
  {
    step: '04',
    title: 'Refinement & Delivery',
    description:
      'Testing across viewports, themes, reduced-motion preferences, and offline states until every interaction feels effortless.',
    outcome: 'Polished, resilient digital launch',
  },
];

export const JOURNEY_MILESTONES: JourneyMilestone[] = [
  {
    phase: 'Chapter 01',
    title: 'Foundations in Visual Curiosity',
    focus: 'Design & Digital Expression',
    description:
      'Started exploring how layout, typography, and digital imagery shape the emotional feel of software.',
  },
  {
    phase: 'Chapter 02',
    title: 'Frontend Craft & Architecture',
    focus: 'React, TypeScript & Responsive Systems',
    description:
      'Focused deeply on clean component engineering, semantic markup, and responsive precision across every screen size.',
  },
  {
    phase: 'Chapter 03',
    title: 'Interactive Motion & Sound',
    focus: 'Creative Development & Web Audio',
    description:
      'Combined canvas atmospheres, controlled kinetic typography, and procedural audio into cohesive digital identities.',
  },
  {
    phase: 'Chapter 04',
    title: 'SOLO Digital Identity',
    focus: 'Unified Web & Mobile-Ready Craft',
    description:
      'Continuing to build ambitious, human-centered web experiences designed cleanly for both desktop immersion and mobile portability.',
  },
];

export const TECH_STACK = [
  'TypeScript',
  'React 19',
  'Tailwind CSS',
  'Motion',
  'HTML5 Canvas',
  'Web Audio API',
  'Vite',
  'PWA / Workbox',
  'Capacitor Ready',
  'WCAG Accessibility',
];

export const SOCIAL_LINKS = [
  { label: 'GitHub', href: 'https://github.com', handle: '@solo-dev' },
  { label: 'X / Twitter', href: 'https://x.com', handle: '@solo_creates' },
  { label: 'Instagram', href: 'https://instagram.com', handle: '@solo.digital' },
  { label: 'LinkedIn', href: 'https://linkedin.com', handle: 'in/solo-digital' },
];
