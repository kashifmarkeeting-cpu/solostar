import type { ThemeConfig, ThemeId } from '../types/solo';

export const THEME_ORDER: ThemeId[] = [
  'royal-purple',
  'cyber-blue',
  'cinematic-red',
  'matrix-green',
];

export const THEMES: Record<ThemeId, ThemeConfig> = {
  'royal-purple': {
    id: 'royal-purple',
    name: 'Royal Purple',
    subtitle: 'Obsidian · Neon Violet · Atmospheric Smoke',
    motif: 'crown-smoke',
    bg: '#07050c',
    surface: '#110c1d',
    surfaceElevated: '#181129',
    accent: '#9333ea',
    accentBright: '#c084fc',
    accentMuted: 'rgba(147, 51, 234, 0.16)',
    border: 'rgba(192, 132, 252, 0.24)',
    borderSubtle: 'rgba(245, 243, 255, 0.08)',
    glow: 'rgba(168, 85, 247, 0.45)',
    text: '#f5f3ff',
    textMuted: '#b8afd1',
    particleColors: ['#a855f7', '#c084fc', '#7e22ce', '#e9d5ff'],
    smokeColor: 'rgba(147, 51, 234, 0.14)',
    harmonicRootHz: 73.42, // D2
    swatchGradient: 'linear-gradient(135deg, #4c1d95 0%, #a855f7 100%)',
  },
  'cyber-blue': {
    id: 'cyber-blue',
    name: 'Cyber Blue',
    subtitle: 'Midnight Navy · Electric Cyan · Precision Grid',
    motif: 'cyber-grid',
    bg: '#040914',
    surface: '#0a1428',
    surfaceElevated: '#101f3c',
    accent: '#0284c7',
    accentBright: '#38bdf8',
    accentMuted: 'rgba(14, 165, 233, 0.16)',
    border: 'rgba(56, 189, 248, 0.25)',
    borderSubtle: 'rgba(224, 242, 254, 0.08)',
    glow: 'rgba(14, 165, 233, 0.44)',
    text: '#f0f9ff',
    textMuted: '#a5c4de',
    particleColors: ['#0ea5e9', '#38bdf8', '#06b6d4', '#bae6fd'],
    smokeColor: 'rgba(14, 165, 233, 0.13)',
    harmonicRootHz: 82.41, // E2
    swatchGradient: 'linear-gradient(135deg, #0c4a6e 0%, #38bdf8 100%)',
  },
  'cinematic-red': {
    id: 'cinematic-red',
    name: 'Cinematic Red',
    subtitle: 'Deep Black · Intense Crimson · Dramatic Rim',
    motif: 'crimson-beams',
    bg: '#090405',
    surface: '#16080c',
    surfaceElevated: '#210d13',
    accent: '#e11d48',
    accentBright: '#fb7185',
    accentMuted: 'rgba(225, 29, 72, 0.16)',
    border: 'rgba(251, 113, 133, 0.25)',
    borderSubtle: 'rgba(255, 241, 242, 0.08)',
    glow: 'rgba(225, 29, 72, 0.45)',
    text: '#fff1f2',
    textMuted: '#d6aeb4',
    particleColors: ['#e11d48', '#fb7185', '#ef4444', '#fecdd3'],
    smokeColor: 'rgba(225, 29, 72, 0.14)',
    harmonicRootHz: 65.41, // C2
    swatchGradient: 'linear-gradient(135deg, #881337 0%, #f43f5e 100%)',
  },
  'matrix-green': {
    id: 'matrix-green',
    name: 'Matrix Green',
    subtitle: 'Void Black · Neon Lime · Digital Lattice',
    motif: 'matrix-rain',
    bg: '#030905',
    surface: '#08140c',
    surfaceElevated: '#0f2115',
    accent: '#16a34a',
    accentBright: '#4ade80',
    accentMuted: 'rgba(34, 197, 94, 0.16)',
    border: 'rgba(74, 222, 128, 0.24)',
    borderSubtle: 'rgba(240, 253, 244, 0.08)',
    glow: 'rgba(34, 197, 94, 0.44)',
    text: '#f0fdf4',
    textMuted: '#a6cbb2',
    particleColors: ['#22c55e', '#4ade80', '#84cc16', '#bbf7d0'],
    smokeColor: 'rgba(34, 197, 94, 0.13)',
    harmonicRootHz: 92.5, // F#2
    swatchGradient: 'linear-gradient(135deg, #14532d 0%, #4ade80 100%)',
  },
};

export function applyThemeCssVariables(theme: ThemeConfig): void {
  const root = document.documentElement;
  root.style.setProperty('--solo-bg', theme.bg);
  root.style.setProperty('--solo-surface', theme.surface);
  root.style.setProperty('--solo-surface-elevated', theme.surfaceElevated);
  root.style.setProperty('--solo-accent', theme.accent);
  root.style.setProperty('--solo-accent-bright', theme.accentBright);
  root.style.setProperty('--solo-accent-muted', theme.accentMuted);
  root.style.setProperty('--solo-border', theme.border);
  root.style.setProperty('--solo-border-subtle', theme.borderSubtle);
  root.style.setProperty('--solo-glow', theme.glow);
  root.style.setProperty('--solo-text', theme.text);
  root.style.setProperty('--solo-text-muted', theme.textMuted);
  root.dataset.soloTheme = theme.id;

  const metaThemeColor = document.querySelector('meta[name="theme-color"]');
  if (metaThemeColor) {
    metaThemeColor.setAttribute('content', theme.bg);
  }
}
